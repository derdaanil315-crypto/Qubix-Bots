# Qubix Bot 2.0.7

Jubbio için AI sohbeti, sunucu kurulum yardımı, moderasyon ve otomatik koruma özellikleri sunan bir bottur.

## Hızlı kurulum (Windows)

### Gerekenler

- Node.js 20 veya üzeri
- Bir Jubbio bot hesabı ve bot tokenı
- AI yanıtları için en az bir sağlayıcı anahtarı (Gemini, Groq veya OpenRouter)

### 1. Botu indirin ve bağımlılıkları kurun

Projeyi indirin/açın, proje klasörünü PowerShell'de açın ve şunları çalıştırın:

```powershell
npm ci
Copy-Item .env.example .env
notepad .env
```

`.env` dosyasına kendi bilgilerinizi girin. `.env.example` içindeki örnek değerler çalışır anahtar değildir. Token ve API anahtarlarını kimseyle paylaşmayın ve GitHub'a yüklemeyin.

### 2. Bot tokenını ve AI sağlayıcısını ayarlayın

`.env` dosyasında:

- `BOT_TOKEN`: Jubbio bot tokenı. Zorunludur.
- `GEMINI_API_KEY_1`: Gemini API anahtarı. Alternatif olarak `GROQ_API_KEY_1` veya `OPENROUTER_API_KEY_1` kullanabilirsiniz.
- İsteğe bağlı olarak bir sağlayıcı için `_2`, `_3` şeklinde birden fazla anahtar ekleyebilirsiniz. Anahtarlar rotasyon/yedekleme için kullanılır; sağlayıcıların kota ve kullanım koşullarını değiştirmez.
- `GEMINI_MODELS`, `GROQ_MODELS`, `OPENROUTER_MODELS`: Hesabınızda erişilebilir virgülle ayrılmış model adları.

Yalnızca kullanacağınız sağlayıcının anahtarını doldurun. Desteklenen diğer ayarlar ve güvenli örnek biçimler `.env.example` dosyasındadır.

### 3. Botu başlatın

```powershell
npm start
```

Bot giriş yaptığında terminalde hazır mesajı görünür. Sağlayıcı anahtarlarını kontrol etmek için `npm run check:providers` komutunu kullanabilirsiniz. Bu kontrol, ayarlı sağlayıcılara gerçek test istekleri gönderir ve API kotası kullanabilir.

## Jubbio tarafındaki kurulum

1. Jubbio geliştirici portalında bot uygulaması oluşturun ve tokenı `.env` dosyasına koyun.
2. Botu kendi sunucunuza ekleyin; sohbet, üye/kanal/rol yönetimi ve moderasyon için ihtiyaç duyduğu izinleri verin.
3. Mesaj içeriğini okuyabilmesi için bot uygulamasında **Message Content** erişimini etkinleştirin.
4. Botun rolünü, işlem yapacağı üyelerin/rollerin üstüne taşıyın. Platformun rol hiyerarşisi botun yetkisini sınırlar.
5. Sadece güvendiğiniz sunucularda kullanın. Doğal dil ile moderasyon ve mimari istekleri gerçek sunucu işlemleri başlatabilir.

## Kullanım

### AI sohbeti ve sunucu mimarı

- `@Qubix Kuantum fiziği nedir?`
- `!soru <sorunuz>` (ayrıca `!ai`, `!q` ve `!mimar`)
- `@Qubix bana bir yazılım topluluğu sunucusu kur`
- `@Qubix oyun odaları ve VIP rolü oluştur`

Bot, kanallardaki konuşma geçmişini sınırlı bağlam olarak kullanır. AI sağlayıcılarına gönderilen istekler ilgili sağlayıcının hizmet şartlarına tabidir.

### Moderasyon ve koruma

- `!sustur @üye 10m [sebep]`, `!susturkaldir @üye`
- `!at @üye [sebep]`, `!yasakla @üye [sebep]`
- `!sil 10`, `!kilit`, `!kilitaç`
- `!uyar @üye [sebep]`, `!uyarilar @üye`, `!uyarisil @üye`
- `!koruma`, `!antilink ac/kapat`, `!antispam ac/kapat`
- `!modlog #kanal`

Bazı işlemler bot etiketlenerek Türkçe doğal dilde de istenebilir. Botun sunucu yönetimi izinlerini yalnızca gerçekten gerekli olanlarla sınırlayın.

## Veriler ve gizlilik

- Tokenlar ve API anahtarları yalnızca yerel `.env` dosyanızda tutulmalıdır. Bu dosya Git'e ve yayın paketine dahil edilmez.
- Moderasyon uyarıları ve sunucu ayarları çalışma klasöründeki `data/` altında saklanır. Bu klasör Git'e ve yayın paketine dahil edilmez.
- AI sağlayıcılarına gönderilen mesaj içeriğini ve kullanılan verileri kendi sunucunuz için bilgilendirin; sağlayıcıların gizlilik ve saklama politikalarını inceleyin.
- Bir token yanlışlıkla paylaşıldıysa sadece dosyadan silmekle yetinmeyin; ilgili sağlayıcı panelinden iptal edip yenisini oluşturun.

## Sürümü paylaşma

Kaynak klasörünü doğrudan ZIP'lemek yerine, proje klasöründe şu komutu çalıştırın:

```powershell
npm run prepare:release
```

Komut, sadece izin verilen kaynak ve dokümantasyon dosyalarıyla `release/qubix-bot-2.0.7/` klasörünü hazırlar. `.env`, `node_modules/`, `data/` ve Git/yerel ayar dosyaları bu pakete kopyalanmaz. Oluşan klasörü ZIP'leyip paylaşabilirsiniz. Aynı hedef klasör zaten varsa komut üzerine yazmaz; eski çıktıyı gözden geçirip kaldırdıktan sonra yeniden çalıştırın.

GitHub'da yayınlamak için bu temiz çıktı klasörünü yeni bir herkese açık depoya yükleyin. Depoyu oluşturmadan önce hedefin **Public** olduğunu ve dosya listesinde `.env`, `data/` veya `node_modules/` bulunmadığını kontrol edin. Kaynak değişikliklerinden sonra yayın çıktısını tekrar oluşturun.

## Geliştirici komutları

```powershell
npm start
npm run check:providers
npm run prepare:release
npm test
```

`npm test`, JavaScript dosyalarının sözdizimini denetler; sağlayıcı bağlantı testi değildir.

## Lisans

Bu proje ISC lisansı ile yayımlanır. Ayrıntılar için [LICENSE](./LICENSE) dosyasına bakın.

## İletişim ve yardım

Bize ulaşmak için Jubbio.com üzerindeki **@perry37** hesabına yazın veya
[Jubbio destek sunucusuna katılıp](https://jubbio.com/invite/I3YZVTYj) yardım isteğinde bulunun.
