import { smartGenerateContent, getPoolStatus } from './gemini-pool.js';

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';
const BLOCK_MS = 5 * 60 * 1000;
const usageMap = new Map();

function collectValues(prefix) {
  const values = [];
  for (let index = 1; index <= 50; index++) {
    const value = process.env[`${prefix}_${index}`]?.trim();
    if (value) values.push(value);
  }
  const single = process.env[prefix]?.trim();
  if (values.length === 0 && single) values.push(single);
  return [...new Set(values)];
}

function collectModels(name, fallback) {
  const models = process.env[name]?.split(',').map(value => value.trim()).filter(Boolean);
  return models?.length ? [...new Set(models)] : fallback;
}

const groqKeys = collectValues('GROQ_API_KEY');
const openRouterKeys = collectValues('OPENROUTER_API_KEY');
const groqModels = collectModels('GROQ_MODELS', ['qwen/qwen3.8-27b', 'openai/gpt-oss-120b']);
const openRouterModels = collectModels('OPENROUTER_MODELS', ['qwen/qwen3.8-27b:free', 'google/gemma-4-31b-it:free']);

function getState(provider, keyIndex, model) {
  const id = `${provider}:${keyIndex}:${model}`;
  if (!usageMap.has(id)) usageMap.set(id, { blockedUntil: 0, requests: 0 });
  return usageMap.get(id);
}

function isRetryable(error) {
  return [408, 409, 429, 500, 502, 503, 504].includes(error.status);
}

async function requestOpenAICompatible(url, key, model, messages, provider, config = {}) {
  const response = await fetch(url, {
    method: 'POST',
    signal: AbortSignal.timeout(20000), // 20 saniye zaman aşımı
    headers: {
      authorization: `Bearer ${key}`,
      'content-type': 'application/json',
      ...(provider === 'openrouter' ? {
        'HTTP-Referer': process.env.OPENROUTER_SITE_URL || 'https://jubbio.com',
        'X-Title': process.env.OPENROUTER_APP_NAME || 'Qubix',
      } : {}),
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.7,
      max_tokens: Number(process.env.AI_MAX_OUTPUT_TOKENS || 1200),
      ...(config.responseMimeType === 'application/json'
        ? { response_format: { type: 'json_object' } }
        : {}),
    }),
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(body?.error?.message || `HTTP ${response.status}`);
    error.status = response.status;
    throw error;
  }

  const text = body?.choices?.[0]?.message?.content;
  if (!text) throw new Error(`${provider} boş yanıt döndürdü.`);
  return text;
}

function buildMessages(systemInstruction, prompt, history) {
  const messages = [{ role: 'system', content: systemInstruction }];
  for (const item of history || []) {
    if (item.role === 'user' || item.role === 'assistant') {
      messages.push({ role: item.role, content: String(item.content).slice(0, 4000) });
    }
  }
  messages.push({ role: 'user', content: prompt });
  return messages;
}

async function tryCompatibleProvider(provider, keys, models, messages, config) {
  const errors = [];
  for (let keyIndex = 0; keyIndex < keys.length; keyIndex++) {
    for (const model of models) {
      const state = getState(provider, keyIndex, model);
      if (state.blockedUntil > Date.now()) continue;
      try {
        const url = provider === 'groq' ? GROQ_URL : OPENROUTER_URL;
        const text = await requestOpenAICompatible(url, keys[keyIndex], model, messages, provider, config);
        state.requests++;
        console.log(`✅ ${provider} yanıtı [Key ${keyIndex + 1}/${keys.length}, Model: ${model}]`);
        return text;
      } catch (error) {
        state.blockedUntil = Date.now() + BLOCK_MS;
        errors.push(`${provider}/${keyIndex + 1}/${model}: ${error.message}`);
        console.warn(`⚠️ ${provider} başarısız [Key ${keyIndex + 1}, ${model}]: ${error.message}`);
        if (!isRetryable(error) && error.status === 401) continue;
      }
    }
  }
  return null;
}

export async function generateAI({ prompt, systemInstruction, history = [], config = {} }) {
  const geminiConfig = {
    contents: prompt,
    config: { ...config, systemInstruction },
  };

  try {
    const response = await smartGenerateContent(geminiConfig);
    console.log('✅ Gemini yanıtı alındı.');
    return response.text || '';
  } catch (error) {
    console.warn(`⚠️ Gemini havuzu tükendi/geçici olarak kullanılamıyor: ${error.message}`);
  }

  const messages = buildMessages(systemInstruction, prompt, history);
  const groqResponse = await tryCompatibleProvider('groq', groqKeys, groqModels, messages, config);
  if (groqResponse) return groqResponse;

  const openRouterResponse = await tryCompatibleProvider('openrouter', openRouterKeys, openRouterModels, messages, config);
  if (openRouterResponse) return openRouterResponse;

  throw new Error('AI_SAGLAYICI_HAVUZU_BOS: Gemini, Groq ve OpenRouter kullanılabilir yanıt veremedi.');
}

export function getAIProviderStatus() {
  return {
    gemini: getPoolStatus(),
    groq: { keys: groqKeys.length, models: groqModels.length },
    openrouter: { keys: openRouterKeys.length, models: openRouterModels.length },
  };
}
