import { generateAI, getAIProviderStatus } from './ai-router.js';

// Qubix'in sistem talimatı (Kişiliği ve Odak Kuralları)
const SYSTEM_INSTRUCTION = `
Sen "Qubix", Jubbio platformu için özel geliştirilmiş zeki, arkadaş canlısı ve yardımsever bir yapay zeka asistanısın.

Altın İletişim Kuralların:
1. ODAKLANMA: Kullanıcının sorusuna doğrudan odaklan. Konuyu dağıtma, lafı uzatma veya alakasız konulara sapma.
2. KIVAMINDA UZUNLUK: Cevapların ne baştan savma kadar kısa ne de okurken yoracak kadar uzun olsun. Tam kararında, net ve özlü açıkla.
3. ANLAŞILIR TÜRKÇE: Hiç bilmeyen birinin bile rahatça anlayacağı, akıcı ve tatlı bir dil kullan.
4. BİLİM VE PROJE YARDIMCISI: Kullanıcı ödev, bilimsel konu, kodlama veya fikir danıştığında pratik, doğru ve öğretici çözümler sun.
5. SAYGI VE ETİK: Her zaman kibar, yapıcı ve dostane kal.
`;

/**
 * Kullanıcının sorusunu Gemini yapay zekasına iletip odaklı cevap alır.
 * Havuz yöneticisi sayesinde birden fazla API key ve model arasında otomatik geçiş yapar.
 * @param {string} userPrompt - Kullanıcının yazdığı mesaj
 * @param {string} userName - Kullanıcının adı
 * @returns {Promise<string>} - Yapay zekanın yanıtı
 */
export async function askGemini(userPrompt, userName = 'Kullanıcı', history = []) {
  try {
    return await generateAI({
      prompt: userPrompt,
      history,
      systemInstruction: SYSTEM_INSTRUCTION,
      config: { temperature: 0.7 },
    });
  } catch (error) {
    // Tüm limitler dolmuşsa
    if (String(error).includes('TÜM_LİMİTLER_DOLDU')) {
      const status = getAIProviderStatus().gemini;
      console.warn(`⚠️ Tüm Gemini havuzu doldu! (${status.totalRequestsUsed}/${status.maxRequestsPerDay} istek kullanıldı)`);
      return '⏳ Bugünkü yapay zeka kullanım limitime ulaştım. Yarın tekrar geldiğinde seni bekliyorum! 😊';
    }

    if (String(error).includes('GEMINI_GECICI_HATA')) {
      return '⏳ Gemini şu anda yoğun görünüyor. Birkaç dakika sonra tekrar dener misin?';
    }

    if (String(error).includes('GEMINI_BEKLEME')) {
      return '⏳ Google Gemini geçici hız/kota sınırı uyguluyor. Birkaç dakika bekleyip tekrar dener misin? Bu, günlük hakkın kesin olarak bittiği anlamına gelmez.';
    }

    if (String(error).includes('AI_SAGLAYICI_HAVUZU_BOS')) {
      return 'Şu anda Gemini, Groq ve OpenRouter sağlayıcılarından kullanılabilir bir yanıt alınamadı. Sağlayıcı durumunu kontrol edip tekrar deneyelim.';
    }

    console.error('AI sağlayıcıları hatası:', error);
    return 'Şu an düşüncelerimi toparlamakta ufak bir aksaklık yaşadım. Birazdan tekrar dener misin?';
  }
}
