import { generateAI } from './ai-router.js';

const ARCHITECT_SYSTEM_INSTRUCTION = `
Sen "Qubix", Jubbio platformuna özel sunucu mimarı ve akıllı moderatörsün.
Görevin, sunucu sahibinin veya yöneticisinin Türkçe doğal dilde söylediği sunucu düzenleme isteklerini analiz etmek ve yapılandırmaktır.

Jubbio Platform Yetenekleri:
- Kanallar: Metin kanalı (type: 0 / "text"), Ses kanalı (type: 2 / "voice"), Kategori (type: 4 / "category").
- Roller: İsim ve renk (decimal sayı, örn: Mavi 3447003, Yeşil 5763719, Turuncu 15105570, Kırmızı 15548997, Mor 10181046 vb.)
- Hiyerarşi: Kanallar bir kategorinin altında toplanabilir.
- Mesajlar: Metin kanallarına bilgilendirici mesaj gönderilebilir ve sabitlenebilir.

İstek Türleri ve Kurallar:
1. "chat": Kullanıcı sunucu düzenlemek istemiyor, sadece sohbet ediyor, soru soruyor veya selam veriyor.
2. "impossible": İstek Jubbio güvenlik kurallarına aykırı, imkansız veya tehlikeli (Örn: sunucu sahibini banlamak, şifreleri istemek, Jubbio sunucularını kapatmak, botu patlatmak vb.).
   - "message": Çok kibar, etik ve net bir dille neden yapılamayacağını açıklayan mesaj.
3. "workaround": Kullanıcının istediği doğrudan bir özellik Jubbio'da yok (Örn: 7/24 kesintisiz radyo istasyonu, yapay zeka müzik üretici botu vb.), ancak Jubbio'nun izin verdiği şekilde mantıklı bir alternatif üretilebilir.
   - "message": Neden doğrudan olmadığını ve önereceğin pratik alternatifi anlatan mesaj.
4. "architect": İstek Jubbio'da yapılabilir (Örn: "bana yazılım sunucusu kur", "oyun odaları ve ses kanalları aç", "moderatör ve üye rolleri oluştur").
   - "summary": Yapılacakları özetleyen tatlı ve net bir Türkçe metin.
   - "categories": Kategoriler dizisi. Her kategorinin adı ve içereceği kanallar ("name", "type": "text"|"voice").
   - "standaloneChannels": Kategorisiz kanallar (varsa).
   - "roles": Oluşturulacak roller ("name", "color": decimal number).
  - "channelMessages": Her metin kanalı için bir duyuru ("channelId", "channelName", "content"). Mesaj; kanalın amacını, üyelerin kanalda ne yapacağını ve temel kullanım kuralını kısa ve Türkçe anlatmalı.

channelMessages alanında yeni oluşturulacak kanallar için mesaj üret. Kullanıcı mevcut kanal kimlikleri verdiyse bunları "existingChannelMessages" alanında aynı formatla planla. Mevcut kanallara mesaj gönderme ve sabitleme bu botun desteklediği bir işlemdir; bu istek için "impossible" veya "workaround" döndürme. Ses kanalları için mesaj üretme.

ÇIKTI FORMATI:
Sadece ve sadece geçerli bir JSON nesnesi döndür. Başka hiçbir metin veya markdown formatı ekleme.
`;

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Kullanıcının mesajını analiz eder ve sunucu mimarlığı planı çıkarır.
 */
export async function analyzeServerRequest(userPrompt, serverName = 'Sunucu', availableChannels = [], history = []) {
  try {
    const channelContext = availableChannels.length > 0
      ? `\nMevcut kanallar (yalnızca mesaj gönderilecek hedefleri belirlemek için): ${JSON.stringify(availableChannels)}`
      : '';
    const prompt = `Sunucu Adı: "${serverName}"\nKullanıcı İsteği: "${userPrompt}"${channelContext}`;
    const responseText = await generateAI({
      prompt,
      history,
      systemInstruction: ARCHITECT_SYSTEM_INSTRUCTION,
      config: { responseMimeType: 'application/json', temperature: 0.3 },
    });

    const parsed = JSON.parse(responseText);
    return parsed;
  } catch (error) {
    console.error('Mimar analizi hatası:', error);
    return { type: 'chat' };
  }
}

/**
 * Onaylanan sunucu planını Jubbio API'si üzerinden hayata geçirir.
 * Jubbio API rate limit (saniyede 1 istek) kurallarına uygun olarak gecikmelerle çalışır.
 */
export async function executeServerPlan(client, guildId, plan) {
  const results = {
    categoriesCreated: [],
    channelsCreated: [],
    rolesCreated: [],
    messagesPinned: [],
    errors: [],
  };
  const createdTextChannels = [];

  try {
    // 1. Kategorileri ve içindeki kanalları oluştur
    if (plan.categories && Array.isArray(plan.categories)) {
      for (const cat of plan.categories) {
        let catId = null;
        try {
          // Rate limit koruması
          await sleep(1200);

          const createdCat = await client.rest.createChannel(guildId, {
            name: cat.name,
            type: 4,
          });
          catId = createdCat?.id;
          results.categoriesCreated.push(cat.name);
        } catch (err) {
          console.error(`Kategori oluşturulamadı (${cat.name}):`, err.message);
          if (err.message.includes('permission')) {
            results.errors.push(`Kategori açılamadı (${cat.name}): Botun sunucuda "Kanalları Yönet" izni yok.`);
          } else {
            results.errors.push(`Kategori açılamadı: ${cat.name}`);
          }
        }

        // Kategori altına kanalları ekle
        if (cat.channels && Array.isArray(cat.channels)) {
          for (const ch of cat.channels) {
            try {
              // Rate limit koruması
              await sleep(1200);

              const chType = ch.type === 'voice' ? 2 : 0;
              const createdChannel = await client.rest.createChannel(guildId, {
                name: ch.name,
                type: chType,
                parent_id: catId || undefined,
              });
              results.channelsCreated.push(`${ch.type === 'voice' ? '🔊' : '💬'} #${ch.name}`);
              if (chType === 0 && createdChannel?.id) {
                createdTextChannels.push({ id: createdChannel.id, name: ch.name });
              }
            } catch (err) {
              console.error(`Kanal oluşturulamadı (${ch.name}):`, err.message);
              if (err.message.includes('permission')) {
                results.errors.push(`Kanal açılamadı (#${ch.name}): Botun sunucuda "Kanalları Yönet" yetkisi eksik.`);
              } else {
                results.errors.push(`Kanal açılamadı: #${ch.name}`);
              }
            }
          }
        }
      }
    }

    // 2. Kategorisiz kanalları oluştur
    if (plan.standaloneChannels && Array.isArray(plan.standaloneChannels)) {
      for (const ch of plan.standaloneChannels) {
        try {
          await sleep(1200);

          const chType = ch.type === 'voice' ? 2 : 0;
          const createdChannel = await client.rest.createChannel(guildId, {
            name: ch.name,
            type: chType,
          });
          results.channelsCreated.push(`${ch.type === 'voice' ? '🔊' : '💬'} #${ch.name}`);
          if (chType === 0 && createdChannel?.id) {
            createdTextChannels.push({ id: createdChannel.id, name: ch.name });
          }
        } catch (err) {
          console.error(`Kanal oluşturulamadı (${ch.name}):`, err.message);
          results.errors.push(`Kanal açılamadı: #${ch.name}`);
        }
      }
    }

    // 3. Metin kanallarına kullanım mesajı gönder ve sabitle
    const existingMessages = Array.isArray(plan.existingChannelMessages)
      ? plan.existingChannelMessages
      : [];
    const newMessages = Array.isArray(plan.channelMessages)
      ? plan.channelMessages
      : [];
    const messagesToSend = [
      ...existingMessages.map(item => ({ ...item, existing: true })),
      ...newMessages.map(item => ({ ...item, existing: false })),
    ];

    for (const channelMessage of messagesToSend) {
      const channel = channelMessage.existing
        ? { id: String(channelMessage.channelId), name: channelMessage.channelName }
        : createdTextChannels.find(item => item.name === channelMessage.channelName);
      if (!channel?.id || !channelMessage.content) continue;

      try {
        await sleep(1200);
        const messageData = await client.rest.createMessage(guildId, channel.id, {
          content: channelMessage.content,
        });
        await client.rest.pinMessage(guildId, channel.id, messageData.id);
        results.messagesPinned.push(`#${channel.name}`);
      } catch (err) {
        console.error(`Kanal mesajı sabitlenemedi (#${channel.name}):`, err.message);
        results.errors.push(`Kanal mesajı sabitlenemedi (#${channel.name}): ${err.message}`);
      }
    }

    if (messagesToSend.length > 0 && results.messagesPinned.length === 0 && results.errors.length === 0) {
      results.errors.push('Kanal mesajı gönderilemedi: Geçerli metin kanalı hedefi bulunamadı.');
    }

    // 4. Rolleri oluştur
    if (plan.roles && Array.isArray(plan.roles)) {
      for (const role of plan.roles) {
        try {
          await sleep(1200);

          await client.rest.createRole(guildId, {
            name: role.name,
            color: role.color || 3447003,
            hoist: true,
            mentionable: true,
          });
          results.rolesCreated.push(`🏷️ @${role.name}`);
        } catch (err) {
          console.error(`Rol oluşturulamadı (${role.name}):`, err.message);
          results.errors.push(`Rol açılamadı: @${role.name}`);
        }
      }
    }
  } catch (globalErr) {
    console.error('Genel inşaat hatası:', globalErr);
    results.errors.push(globalErr.message);
  }

  return results;
}
