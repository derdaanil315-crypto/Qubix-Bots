import { getGuildSettings, timeoutUser, warnMember } from './moderation.js';

// Kullanıcı mesaj geçmişi takibi (Spam tespiti için in-memory)
// key: "guildId:userId" -> { timestamps: [], lastMessage: '', repeatCount: 0 }
const userActivity = new Map();

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Link regex modelleri
const INVITE_REGEX = /(?:discord(?:\.gg|app\.com\/invite|\.com\/invite)|jubbio(?:\.com\/invite|\.com\/join)|jub\.bio)\/([a-zA-Z0-9\-]+)/i;
const GENERAL_LINK_REGEX = /https?:\/\/[^\s<]+[^<.,:;"')\]\s]/i;

/**
 * Mesajı otomatik moderasyon kurallarına göre denetler.
 * Eğer bir kural ihlali varsa gerekli yaptırımı uygular ve true döndürür (mesaj işlenmeyecek).
 *
 * @param {object} client - Jubbio client
 * @param {object} message - Jubbio message objesi
 * @param {boolean} isPrivileged - Mesajı atan kişi yetkili mi (admin/owner/mod)?
 * @returns {Promise<boolean>} - Mesaj ihlal nedeniyle engellendiyse true
 */
export async function checkAutoMod(client, message, isPrivileged = false) {
  // Yetkililer, botlar veya DM'lerde auto-mod devre dışı
  if (isPrivileged || message.author?.bot || !message.guildId) {
    return false;
  }

  const guildId = message.guildId;
  const channelId = message.channelId;
  const authorId = message.author?.id;
  const content = message.content ? message.content.trim() : '';
  if (!content) return false;

  const settings = getGuildSettings(guildId);
  const userKey = `${guildId}:${authorId}`;
  const now = Date.now();

  // 1. ANTİ-LİNK / REKLAM ENGELLEME
  if (settings.antiLink) {
    const hasLink = INVITE_REGEX.test(content) || GENERAL_LINK_REGEX.test(content);
    if (hasLink) {
      try {
        await client.rest.deleteMessage(guildId, channelId, message.id);
        await sleep(300);
        await client.rest.createMessage(guildId, channelId, {
          content: `⚠️ <@${authorId}>, bu sunucuda **link veya reklam paylaşımı yasaktır!**`,
        });

        // Kullanıcıya otomatik uyarı ekle
        await warnMember(client, guildId, authorId, 'Anti-Link: İzinsiz bağlantı/reklam paylaşımı', {
          username: 'Qubix Auto-Mod',
          id: String(client.user?.id || 'Qubix'),
        });

        console.log(`🛡️ [AutoMod] Link engellendi: ${message.author.username} (${guildId})`);
        return true;
      } catch (err) {
        console.warn('Anti-link işlemi başarısız:', err.message);
      }
    }
  }

  // 2. ANTİ-SPAM VE FLOOD ENGELLEME
  if (settings.antiSpam) {
    if (!userActivity.has(userKey)) {
      userActivity.set(userKey, { timestamps: [], lastMessage: '', repeatCount: 0 });
    }

    const activity = userActivity.get(userKey);
    // Son 5 saniye dışındaki mesajları temizle
    activity.timestamps = activity.timestamps.filter((t) => now - t < 5000);
    activity.timestamps.push(now);

    // Tekrarlanan mesaj kontrolü
    if (activity.lastMessage === content.toLowerCase()) {
      activity.repeatCount++;
    } else {
      activity.lastMessage = content.toLowerCase();
      activity.repeatCount = 1;
    }

    // İhlal 1: 5 saniyede 5+ mesaj (Hızlı flood)
    // İhlal 2: Aynı mesajı arka arkaya 3+ kez atma (Tekrar spamı)
    if (activity.timestamps.length >= 5 || activity.repeatCount >= 3) {
      try {
        await client.rest.deleteMessage(guildId, channelId, message.id);
        await sleep(300);

        // 2 dakika sustur
        const twoMinutes = 2 * 60 * 1000;
        await timeoutUser(client, guildId, authorId, twoMinutes, 'Anti-Spam: Hızlı mesaj veya flood gönderimi', {
          username: 'Qubix Auto-Mod',
          id: String(client.user?.id || 'Qubix'),
        });

        await client.rest.createMessage(guildId, channelId, {
          content: `🛑 <@${authorId}>, aşırı hızlı mesaj veya tekrar gönderdiğin için **2 dakika susturuldun!**`,
        });

        // Sayacı sıfırla
        userActivity.delete(userKey);
        console.log(`🛡️ [AutoMod] Spam susturması: ${message.author.username} (${guildId})`);
        return true;
      } catch (err) {
        console.warn('Anti-spam işlemi başarısız:', err.message);
      }
    }
  }

  // 3. AŞIRI CAPSLOCK ENGELLEME
  if (settings.antiCaps && content.length >= 12) {
    const letters = content.replace(/[^a-zA-ZğüşıöçĞÜŞİÖÇ]/g, '');
    if (letters.length >= 10) {
      const uppercaseCount = letters.split('').filter((c) => c === c.toUpperCase() && c !== c.toLowerCase()).length;
      const ratio = uppercaseCount / letters.length;

      if (ratio >= 0.75) {
        try {
          await client.rest.deleteMessage(guildId, channelId, message.id);
          await sleep(300);
          await client.rest.createMessage(guildId, channelId, {
            content: `⚠️ <@${authorId}>, lütfen sohbette **aşırı büyük harf (capslock)** kullanma.`,
          });
          console.log(`🛡️ [AutoMod] Capslock engellendi: ${message.author.username} (${guildId})`);
          return true;
        } catch (err) {
          console.warn('Anti-caps işlemi başarısız:', err.message);
        }
      }
    }
  }

  return false;
}
