const MAX_HISTORY = Number(process.env.AI_HISTORY_LIMIT || 20);

function getMessageList(result) {
  if (Array.isArray(result)) return result;
  if (Array.isArray(result?.messages)) return result.messages;
  if (Array.isArray(result?.data)) return result.data;
  return [];
}

export async function getChannelHistory(client, guildId, channelId) {
  if (!guildId || !channelId) return [];

  try {
    const result = await client.rest.getMessages(guildId, channelId, { limit: MAX_HISTORY });
    return getMessageList(result)
      .filter(message => message?.content)
      .slice(-MAX_HISTORY)
      .map(message => ({
        role: String(message.author?.id || message.user_id) === String(client.user?.id)
          ? 'assistant'
          : 'user',
        author: message.author?.username || message.author?.display_name || 'Kullanıcı',
        content: String(message.content).slice(0, 4000),
      }));
  } catch (error) {
    console.warn(`⚠️ Kanal geçmişi alınamadı (${channelId}): ${error.message}`);
    return [];
  }
}
