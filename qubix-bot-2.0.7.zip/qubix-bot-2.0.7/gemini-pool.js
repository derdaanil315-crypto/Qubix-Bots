import { GoogleGenAI } from '@google/genai';

/**
 * Gemini API Havuz Yöneticisi
 * 
 * Birden fazla API key ve model arasında otomatik geçiş yapar.
 * Bir key/model kombinasyonu 429 (limit) hatası alırsa sonrakine geçer.
 * 
 * .env dosyasında şu şekilde tanımlanır:
 *   GEMINI_API_KEY_1=abc...
 *   GEMINI_API_KEY_2=def...
 *   GEMINI_API_KEY_3=ghi...
 *   GEMINI_API_KEY_4=jkl...
 *   (veya tek key için eski format: GEMINI_API_KEY=abc...)
 * 
 * Opsiyonel ayarlar:
 *   GEMINI_PER_COMBO_LIMIT=18   → Her key+model kombinasyonu için günlük limit (varsayılan: 18)
 *   GEMINI_MODELS=gemini-2.5-flash,gemini-2.0-flash,gemini-1.5-flash  → Kullanılacak modeller (virgülle ayrılmış)
 */

// Kullanılacak modeller (öncelik sırasıyla) - .env'den özelleştirilebilir
// Eski/yanlış model isimleri 404/"not available to new users" hatası verdiği için,
// daha güvenilir ve aktif Google Gemini modelleri tercih edilir.
const DEFAULT_MODELS = [
  'gemini-3.8-flash',
  'gemini-2.5-flash',
];

function getModelsFromEnv() {
  const envModels = process.env.GEMINI_MODELS;
  if (envModels && envModels.trim()) {
    const models = envModels.split(',').map(m => m.trim()).filter(Boolean);
    if (models.length > 0) {
      return [...new Set([...DEFAULT_MODELS, ...models])].slice(0, 3);
    }
  }
  return DEFAULT_MODELS;
}

const MODELS = getModelsFromEnv();

// .env'den tüm API key'leri topla
function collectApiKeys() {
  const keys = [];

  // Numaralı key'ler: GEMINI_API_KEY_1, GEMINI_API_KEY_2, ...
  for (let i = 1; i <= 20; i++) {
    const key = process.env[`GEMINI_API_KEY_${i}`];
    if (key && key.trim()) keys.push(key.trim());
  }

  // Eski format (tek key): GEMINI_API_KEY
  if (keys.length === 0 && process.env.GEMINI_API_KEY) {
    keys.push(process.env.GEMINI_API_KEY.trim());
  }

  return [...new Set(keys)];
}

// Havuz oluştur
const apiKeys = collectApiKeys();
const clients = apiKeys.map(key => new GoogleGenAI({ apiKey: key }));

// Her key+model kombinasyonu için istek sayacı
// key: "keyIndex:model" → { count, blockedUntil, hardBlocked }
const usageMap = new Map();

// Başarılı istekleri havuza dengeli dağıtmak için rotasyon imleci.
let rotationCursor = 0;

// Her key+model kombinasyonu için günlük limit (.env'den okunur, varsayılan 18)
const PER_COMBO_LIMIT = parseInt(process.env.GEMINI_PER_COMBO_LIMIT, 10) || 18;

// 429 dışı hatalarda (geçersiz key, model bulunamadı vb.) kombinasyonu ne kadar süre blokla (ms)
const HARD_BLOCK_MS = 30 * 60 * 1000; // 30 dakika

function getUsageKey(keyIndex, model) {
  return `${keyIndex}:${model}`;
}

function getUsage(keyIndex, model) {
  const key = getUsageKey(keyIndex, model);
  if (!usageMap.has(key)) {
    usageMap.set(key, { count: 0, blockedUntil: 0, hardBlocked: false });
  }
  return usageMap.get(key);
}

// 24 saatte bir sayaçları sıfırla
let lastReset = Date.now();
function resetIfNeeded() {
  if (Date.now() - lastReset > 24 * 60 * 60 * 1000) {
    usageMap.clear();
    lastReset = Date.now();
    console.log('🔄 Gemini havuzu: Günlük sayaçlar sıfırlandı.');
  }
}

/**
 * Tüm key+model kombinasyonlarını deneyen akıllı generateContent.
 * 
 * @param {object} config - { contents, config: { systemInstruction, temperature, responseMimeType } }
 * @returns {Promise<object>} - Gemini yanıtı
 * @throws {Error} - Tüm kombinasyonlar tükendiyse
 */
export async function smartGenerateContent(config) {
  resetIfNeeded();

  const errors = [];
  if (clients.length === 0 || MODELS.length === 0) {
    throw new Error('GEMINI_HAVUZU_BOS: En az bir Gemini API anahtarı ve model tanımlanmalı.');
  }

  const combinations = [];
  for (let ki = 0; ki < clients.length; ki++) {
    for (const model of MODELS) {
      combinations.push({ keyIndex: ki, model });
    }
  }

  const startIndex = rotationCursor % combinations.length;
  rotationCursor = (rotationCursor + 1) % combinations.length;

  // Her istekte farklı bir noktadan başlayarak geçici arızayı tek noktada toplama.
  for (let offset = 0; offset < combinations.length; offset++) {
    const { keyIndex: ki, model } = combinations[(startIndex + offset) % combinations.length];
    const usage = getUsage(ki, model);

    // Bu kombinasyon bloklanmış mı?
    if (usage.hardBlocked && usage.blockedUntil > Date.now()) continue;
    if (usage.blockedUntil > Date.now()) continue;
    if (usage.count >= PER_COMBO_LIMIT) continue;

    try {
      const response = await clients[ki].models.generateContent({
        model,
        contents: config.contents,
        config: config.config || {},
      });

      usage.count++;
      console.log(`✅ Gemini yanıt alındı [Key ${ki + 1}/${clients.length}, Model: ${model}, Kullanım: ${usage.count}/${PER_COMBO_LIMIT}]`);
      return response;

    } catch (err) {
      const errMsg = err?.message || String(err);
      const is429 = err?.status === 429 ||
                    String(err).includes('429') ||
                    String(err).includes('RESOURCE_EXHAUSTED') ||
                    errMsg.includes('429') ||
                    errMsg.includes('RESOURCE_EXHAUSTED');

      if (is429) {
        const delaySec = extractRetryDelay(err);
        usage.blockedUntil = Date.now() + delaySec * 1000;
        console.warn(`⚠️ Gemini 429 [Key ${ki + 1}, ${model}] → ${delaySec}s bloklandı. Sonraki kombinasyona geçiliyor...`);
        errors.push(`Key${ki + 1}/${model}: 429 geçici hız/kota reddi`);
        continue;
      }

        // Geçersiz API key veya model hatası mı? (tekrar tekrar denemeyi engelle)
        const isInvalidKey = errMsg.includes('API key') ||
                 errMsg.includes('api_key') ||
                 errMsg.includes('UNAUTHENTICATED') ||
                 errMsg.includes('PERMISSION_DENIED') ||
                 errMsg.includes('403');

        const isModelNotFound = errMsg.includes('model') &&
                (errMsg.includes('not found') || errMsg.includes('NOT_FOUND') || errMsg.includes('404'));

      if (isInvalidKey || isModelNotFound) {
        usage.hardBlocked = true;
        usage.blockedUntil = Date.now() + HARD_BLOCK_MS;
        console.warn(`🚫 Gemini kalıcı hata [Key ${ki + 1}, ${model}]: ${errMsg.slice(0, 120)} → 30dk bloklandı.`);
        errors.push(`Key${ki + 1}/${model}: ${errMsg.slice(0, 80)}`);
        continue;
      }

      // Diğer geçici hatalar (ağ, zaman aşımı vb.) - 5 dakika blokla
      usage.blockedUntil = Date.now() + 5 * 60 * 1000;
      console.error(`❌ Gemini hata [Key ${ki + 1}, ${model}]:`, errMsg.slice(0, 200));
      errors.push(`Key${ki + 1}/${model}: ${errMsg.slice(0, 100)}`);
      continue;
    }
  }

  // Hiçbir kombinasyon çalışmadı
  const hasTemporaryFailure = errors.some(error => error.includes('503') || error.includes('UNAVAILABLE'));
  if (hasTemporaryFailure) {
    throw new Error(`GEMINI_GECICI_HATA: Gemini şu anda geçici olarak yanıt vermiyor. (${errors.join(', ')})`);
  }

  const hasOnlyRateLimitFailures = errors.length > 0 && errors.every(error => error.includes('429'));
  if (hasOnlyRateLimitFailures) {
    throw new Error(`GEMINI_BEKLEME: Gemini geçici hız veya kota sınırı uyguluyor. (${errors.join(', ')})`);
  }

  throw new Error(`TÜM_LİMİTLER_DOLDU: Tüm API key ve model kombinasyonları tükendi. (${errors.join(', ')})`);
}

/**
 * Havuz durumunu özetler.
 */
export function getPoolStatus() {
  resetIfNeeded();
  const totalCombos = clients.length * MODELS.length;
  let available = 0;
  let totalUsed = 0;

  for (let ki = 0; ki < clients.length; ki++) {
    for (const model of MODELS) {
      const usage = getUsage(ki, model);
      totalUsed += usage.count;
      if (usage.count < PER_COMBO_LIMIT && usage.blockedUntil <= Date.now()) {
        available++;
      }
    }
  }

  return {
    totalKeys: clients.length,
    totalModels: MODELS.length,
    totalCombinations: totalCombos,
    availableCombinations: available,
    totalRequestsUsed: totalUsed,
    maxRequestsPerDay: totalCombos * PER_COMBO_LIMIT,
  };
}

/**
 * 429 hatasından retryDelay (saniye) değerini çıkarır.
 */
function extractRetryDelay(error) {
  try {
    const msg = error?.message || String(error);
    const match = msg.match(/retry\s+in\s+([\d.]+)/i);
    if (match) return Math.ceil(Number(match[1]));
  } catch (_) {}
  return 60;
}