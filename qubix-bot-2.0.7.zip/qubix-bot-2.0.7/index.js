import 'dotenv/config';
import { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } from '@jubbio/core';
import { askGemini } from './ai.js';
import { analyzeServerRequest, executeServerPlan } from './architect.js';
import { getChannelHistory } from './conversation-memory.js';
import {
  timeoutUser,
  untimeoutUser,
  kickUser,
  banUser,
  unbanUser,
  purgeMessages,
  lockChannel,
  unlockChannel,
  warnMember,
  getWarnings,
  clearWarnings,
  getGuildSettings,
  updateGuildSettings,
  parseDuration,
  formatDuration,
  parseNaturalModeration,
} from './moderation.js';
import { checkAutoMod } from './automod.js';

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function createChannelGuide(channelName) {
  const normalizedName = channelName
    .toLocaleLowerCase('tr-TR')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
  const title = `#${channelName}`;

  if (normalizedName.includes('komut')) {
    return `📌 **${title} kanalı**\n\nBu kanal bot komutlarını denemek için kullanılır. Komutları burada yazabilir, botun verdiği yanıtları inceleyebilir ve komut kullanımını öğrenebilirsin. Gereksiz sohbeti bu kanalda yapmayalım.`;
  }
  if (normalizedName.includes('log')) {
    return `📌 **${title} kanalı**\n\nBu kanal bot ve sunucu olaylarının kayıtlarını takip etmek içindir. Sistem hareketleri ve otomatik işlemler burada görünür. Normal sohbet mesajlarını bu kanala göndermeyelim.`;
  }
  if (normalizedName.includes('hata') || normalizedName.includes('rapor')) {
    return `📌 **${title} kanalı**\n\nKarşılaştığın hataları burada bildirebilirsin. Sorunu anlatırken ne yaptığını, aldığın hata mesajını ve mümkünse ekran görüntüsünü ekle. Böylece yöneticiler daha hızlı yardımcı olabilir.`;
  }
  if (normalizedName.includes('duyuru') || normalizedName.includes('guncelle')) {
    return `📌 **${title} kanalı**\n\nSunucuyla ilgili önemli duyurular, yenilikler ve güncellemeler burada paylaşılır. Üyelerin gelişmeleri kaçırmamak için bu kanalı takip etmesi önerilir.`;
  }
  if (normalizedName.includes('sohbet') || normalizedName.includes('chat')) {
    return `📌 **${title} kanalı**\n\nGünlük sohbet, tanışma ve topluluk içi paylaşımlar için kullanılır. Birbirimize saygılı olalım; konuya özel konuşmalar için uygun kanalları tercih edelim.`;
  }

  return `📌 **${title} kanalı**\n\nBu kanalın amacı burada paylaşılır. Mesajlarını kanal konusuyla ilgili tut, diğer üyelerle saygılı iletişim kur ve konu dışı sohbetler için uygun kanalı kullan.`;
}

function isExplicitChannelMessageRequest(prompt) {
  if (!prompt || !prompt.trim()) return false;

  const normalizedPrompt = prompt.trim();

  if (/(rol|role|yetki|izin|düzenle|güncelle|değiştir|özel rol|kanal.*rol|üye.*rol|kullanıcı.*rol|mesaj\s+isteği|mesaj\s+atma\s+isteği|yazma\s+isteği)/i.test(normalizedPrompt)) {
    return false;
  }

  const explicitPatterns = [
    /(?:<#!?\d+>\s*\b(?:mesaj(?:ı|i)?|yaz|gönder|at)\b)/i,
    /(?:\b(?:mesaj(?:ı|i)?|yaz|gönder|at)\b)\s*[:：]\s*(?:["“”'].*?["“”']|\{[\s\S]+?\}|\(.*?\)|.+)/i,
    /(?:kanal(?:ına|a)|şu kanala|bu kanala).*?(?:\b(?:mesaj(?:ı|i)?|yaz|gönder|at)\b)/i,
    /\{[\s\S]+?\}\s*(?:\b(?:mesaj(?:ı|i)?|yaz|gönder|at)\b)/i,
    /\([^()]+\)\s*(?:\b(?:mesaj(?:ını|ı|i)?|yaz|gönder|at)\b)/i,
    /(?:\b(?:mesaj(?:ı|i)?|şunu yaz|şunu gönder|gönder|at)\b)\s*["“”'][^"“”']+["“”']/i,
  ];

  return explicitPatterns.some((pattern) => pattern.test(normalizedPrompt));
}

function extractCustomChannelMessage(prompt) {
  if (!prompt || !prompt.trim()) return null;

  const normalizedPrompt = prompt.trim();
  if (/(rol|role|yetki|izin|düzenle|güncelle|değiştir|özel rol|kanal.*rol|üye.*rol|kullanıcı.*rol|mesaj\s+isteği|mesaj\s+atma\s+isteği|yazma\s+isteği)/i.test(normalizedPrompt)) {
    return null;
  }

  const afterTag = normalizedPrompt.replace(/<#!?\d+>/g, '').trim();

  const explicitPatterns = [
    /(?:\b(?:mesaj(?:ı|i)?|şunu yaz|şunu gönder|gönder|at)\b)\s*[:：]\s*(?:["“”']([^"“”']+)["“”']|\{([\s\S]+?)\}|\(([^()]+)\)|(.+))/i,
    /(?:kanal(?:ına|a)|şu kanala|bu kanala)\s*(?:["“”']([^"“”']+)["“”']|\{([\s\S]+?)\}|\(([^()]+)\)|(.+?))\s*(?:\b(?:yaz|gönder|at)\b)/i,
    /\{([\s\S]+?)\}\s*(?:\b(?:mesaj(?:ı|i)?|yaz|gönder|at)\b)/i,
    /\(([^()]+)\)\s*(?:\b(?:mesaj(?:ını|ı|i)?|yaz|gönder|at)\b)/i,
    /(?:\b(?:mesaj(?:ı|i)?|şunu yaz|şunu gönder|gönder|at)\b)\s*["“”']([^"“”']+)["“”']/i,
  ];

  for (const pattern of explicitPatterns) {
    const match = normalizedPrompt.match(pattern) || afterTag.match(pattern);
    if (!match) continue;

    const candidate = [match[1], match[2], match[3], match[4], match[5], match[6]].find(
      (value) => value && String(value).trim().length > 1,
    );

    if (!candidate) continue;

    const clean = String(candidate)
      .trim()
      .replace(/^[:：\-\s]+/, '')
      .replace(/[\s]+$/, '')
      .replace(/[.]+$/, '');

    if (clean && !/^(mesaj|yaz|gönder|at|kanal|kanala)$/i.test(clean)) {
      return clean;
    }
  }

  const braceMatch = normalizedPrompt.match(/\{([\s\S]+?)\}/) || afterTag.match(/\{([\s\S]+?)\}/);
  if (braceMatch) {
    const value = String(braceMatch[1]).trim();
    const clean = value.replace(/^[:：\-\s]+/, '').replace(/[\s;\-]+$/, '');
    if (clean && clean.length > 2 && /(mesaj|yaz|gönder|at|kanal)/i.test(normalizedPrompt)) {
      return clean;
    }
  }

  const quotedText = [...normalizedPrompt.matchAll(/["“”']([^"“”'\n]+?)["“”']/g)]
    .map((match) => match[1].trim())
    .find((value) => value.length > 1 && !/^(mesaj|yaz|gönder|at)$/i.test(value));

  if (quotedText) return quotedText;

  if (isExplicitChannelMessageRequest(normalizedPrompt)) {
    const fallbackText = afterTag
      .replace(/^(?:şunu|bunu|onu|bu|şu)\s+/i, '')
      .replace(/^(?:mesaj(?:ı|i)?|yaz|gönder|at)\s*[:：-]*/i, '')
      .replace(/(?:kanal(?:ına|a)|şu kanala|bu kanala)/gi, '')
      .replace(/["“”'(){}]/g, '')
      .replace(/[.]+$/, '')
      .trim();

    if (fallbackText && fallbackText.length > 1 && !/^(mesaj|yaz|gönder|at)$/i.test(fallbackText)) {
      return fallbackText;
    }
  }

  return null;
}

function getColorFromText(text) {
  if (!text) return 3447003;

  const normalized = text.toLocaleLowerCase('tr-TR');
  const colorMap = {
    kirmizi: 15548997,
    kırmızı: 15548997,
    mavi: 3447003,
    yesil: 5763719,
    yeşil: 5763719,
    turuncu: 15105570,
    mor: 10181046,
    sari: 16776960,
    sarı: 16776960,
    siyah: 0,
    beyaz: 16777215,
    gri: 8421504,
    grisi: 8421504,
  };

  for (const [name, value] of Object.entries(colorMap)) {
    if (normalized.includes(name)) return value;
  }

  return 3447003;
}

function getChannelPermissionMode(mode) {
  const normalized = String(mode || '').toLocaleLowerCase('tr-TR');

  if (normalized.includes('sadece oku') || normalized.includes('read only') || normalized.includes('yalnızca oku') || normalized.includes('okuma')) {
    return { allow: '1024', deny: '2048' };
  }

  if (normalized.includes('tam') || normalized.includes('hepsi') || normalized.includes('full access') || normalized.includes('izin ver')) {
    return { allow: '3072', deny: '0' };
  }

  return { allow: '3072', deny: '0' };
}

async function handleRoleManagementRequest(client, guildId, message, cleanPrompt) {
  if (!guildId) return false;

  const roleActionPattern = /(rol|role|yetki)/i;
  const actionPattern = /(oluştur|yarat|aç|ekle|düzenle|güncelle|değiştir|ver|al|kaldır|kanal|özel)/i;
  if (!roleActionPattern.test(cleanPrompt) || !actionPattern.test(cleanPrompt)) return false;

  const hasPerm = await checkServerPermission(client, guildId, message.member, message.author.id);
  if (!hasPerm) {
    await message.reply('🔒 Bu sunucu rol ve kanal yetkisi işlemlerini sadece yöneticiler veya sunucu sahibi yapabilir.');
    return true;
  }

  const roleList = await client.rest.getRoles(guildId);
  const roles = Array.isArray(roleList) ? roleList : roleList?.roles || [];
  const channelIds = [...cleanPrompt.matchAll(/<#!?(\d+)>/g)].map(match => match[1]);
  const userIds = [...cleanPrompt.matchAll(/<@!?(\d+)>/g)].map(match => match[1]);
  const roleMentions = [...cleanPrompt.matchAll(/<@&(\d+)>/g)].map(match => match[1]);

  const extractRoleName = () => {
    const patterns = [
      /(?:rol(?:\s+|\s*[:\-])|role(?:\s+|\s*[:\-]))(?:["']([^"']+)["']|\{([^{}]+)\}|([^\n]+))/i,
      /(?:rol|role)\s+(?:oluştur|yarat|aç|ekle)\s+([^\n]+)/i,
      /(?:rol|role)\s+(?:ver|dağıt|ekle)\s+([^\n]+)/i,
    ];

    for (const pattern of patterns) {
      const match = cleanPrompt.match(pattern);
      if (match) {
        const found = [match[1], match[2], match[3], match[4]].find(Boolean);
        if (found) return found.trim();
      }
    }

    return null;
  };

  const targetRoleName = extractRoleName();
  const targetChannelId = channelIds[0] || null;
  const targetUserId = userIds.find(id => id !== String(client.user?.id || '')) || null;

  try {
    if (/(rol|role)\s+(oluştur|yarat|aç|ekle)/i.test(cleanPrompt)) {
      const roleName = targetRoleName || 'Yeni Rol';
      const createdRole = await client.rest.createRole(guildId, {
        name: roleName,
        color: getColorFromText(cleanPrompt),
        hoist: true,
        mentionable: true,
      });

      const finalRoleId = createdRole?.id || createdRole?.role_id || null;
      if (finalRoleId && targetChannelId) {
        const permission = getChannelPermissionMode(cleanPrompt);
        await client.rest.editChannelPermissions(targetChannelId, finalRoleId, {
          type: 'role',
          allow: permission.allow,
          deny: permission.deny,
        });
      }

      await message.reply(`✅ Rol oluşturuldu: @${roleName}${targetChannelId ? ` — <#${targetChannelId}> için hazır.` : ' — genel sunucu için hazır.'}`);
      return true;
    }

    if (/(rol|role)\s+(düzenle|güncelle|değiştir)/i.test(cleanPrompt) || /renk/i.test(cleanPrompt)) {
      const matchRole = roles.find(role =>
        role && (
          role.id === roleMentions[0] ||
          role.name === targetRoleName ||
          role.name?.toLocaleLowerCase('tr-TR').includes(String(targetRoleName || '').toLocaleLowerCase('tr-TR'))
        )
      );

      if (!matchRole) {
        await message.reply('⚠️ Düzenlenecek rol bulunamadı. Rol adını veya rol etiketini net yaz.');
        return true;
      }

      await client.rest.editRole(guildId, matchRole.id, {
        name: targetRoleName || matchRole.name,
        color: getColorFromText(cleanPrompt),
      });
      await message.reply(`✅ Rol güncellendi: @${targetRoleName || matchRole.name}`);
      return true;
    }

    if (/(rol|role)\s+(ver|dağıt|ekle)\b|(?:üye|kullanıcı).*?(rol|role)/i.test(cleanPrompt)) {
      let role = null;
      if (roleMentions[0]) {
        role = roles.find(item => String(item.id) === String(roleMentions[0]));
      }

      if (!role && targetRoleName) {
        role = roles.find(item => item.name?.toLocaleLowerCase('tr-TR') === targetRoleName.toLocaleLowerCase('tr-TR')) ||
          roles.find(item => item.name?.toLocaleLowerCase('tr-TR').includes(targetRoleName.toLocaleLowerCase('tr-TR')));
      }

      if (!role || !targetUserId) {
        await message.reply('⚠️ Rol ve kullanıcı bilgisi eksik. Kullanıcı etiketini ve rolü açıkça yazmalısın.');
        return true;
      }

      await client.rest.addMemberRole(guildId, targetUserId, role.id, 'Rol verildi');
      await message.reply(`✅ ${role.name} rolü <@${targetUserId}> kullanıcısına verildi.`);
      return true;
    }

    if (/(rol|role)\s+(al|kaldır|çıkar)\b/i.test(cleanPrompt)) {
      let role = null;
      if (roleMentions[0]) {
        role = roles.find(item => String(item.id) === String(roleMentions[0]));
      }

      if (!role && targetRoleName) {
        role = roles.find(item => item.name?.toLocaleLowerCase('tr-TR') === targetRoleName.toLocaleLowerCase('tr-TR')) ||
          roles.find(item => item.name?.toLocaleLowerCase('tr-TR').includes(targetRoleName.toLocaleLowerCase('tr-TR')));
      }

      if (!role || !targetUserId) {
        await message.reply('⚠️ Kaldırılacak rol ve kullanıcı bilgisi eksik.');
        return true;
      }

      await client.rest.removeMemberRole(guildId, targetUserId, role.id, 'Rol kaldırıldı');
      await message.reply(`✅ ${role.name} rolü <@${targetUserId}> kullanıcısından alındı.`);
      return true;
    }

    if (/(kanal.*rol|rol.*kanal|kanala özel rol|özel rol.*kanal)/i.test(cleanPrompt)) {
      const roleName = targetRoleName || 'Özel Rol';
      const createdRole = await client.rest.createRole(guildId, {
        name: roleName,
        color: getColorFromText(cleanPrompt),
        hoist: false,
        mentionable: true,
      });

      if (targetChannelId && createdRole?.id) {
        const permission = getChannelPermissionMode(cleanPrompt);
        await client.rest.editChannelPermissions(targetChannelId, createdRole.id, {
          type: 'role',
          allow: permission.allow,
          deny: permission.deny,
        });
      }

      await message.reply(`✅ Kanal özel rol oluşturuldu: @${roleName}${targetChannelId ? ` — <#${targetChannelId}> için ayarlandı.` : ' — hazır.'}`);
      return true;
    }

    await message.reply('🛠️ Rol ve kanal yönetimi örnekleri: "@Qubix rol oluştur Moderatör", "@Qubix <@123> kullanıcısına Moderator rolü ver", "@Qubix <#456> kanalına özel rol oluştur VIP"');
    return true;
  } catch (err) {
    console.error('Rol yönetimi hatası:', err);
    await message.reply(`⚠️ Rol/kanal yönetimi sırasında hata oluştu: ${err.message || 'Bilinmeyen hata'}`);
    return true;
  }
}

/**
 * Klasik Moderasyon Komutlarını İşler (!sustur, !at, !yasakla, !sil, !kilit, !uyar vb.)
 */
async function handleModerationCommands(client, message, content, guildId) {
  if (!guildId) return false;
  const args = content.split(/\s+/);
  const cmd = args[0].toLowerCase();

  const modCommands = [
    '!sustur', '!timeout', '!mute',
    '!susturkaldir', '!susturmakaldir', '!untimeout', '!unmute',
    '!at', '!kick',
    '!yasakla', '!ban',
    '!yasakkaldir', '!unban',
    '!sil', '!temizle', '!purge',
    '!kilit', '!lock',
    '!kilitaç', '!kilitac', '!unlock',
    '!uyar', '!warn',
    '!uyarilar', '!warnings', '!sicil',
    '!uyarisil', '!clearwarns',
    '!koruma', '!guvenlik', '!automod',
    '!antilink', '!antispam', '!anticaps',
    '!modlog'
  ];

  if (!modCommands.includes(cmd)) return false;

  const isMod = await checkModeratorPermission(client, guildId, message.member, message.author.id);
  if (!isMod) {
    await message.reply('🔒 Bu moderasyon komutunu kullanmak için yetkiniz bulunmuyor.');
    return true;
  }

  const targetMentionMatch = content.match(/<@!?(\d+)>/);
  const targetUserId = targetMentionMatch ? targetMentionMatch[1] : (args[1]?.match(/^\d{16,21}$/) ? args[1] : null);

  try {
    // 1. SUSTURMA (!sustur @kullanıcı 10m sebep)
    if (cmd === '!sustur' || cmd === '!timeout' || cmd === '!mute') {
      if (!targetUserId) {
        await message.reply('⚠️ Kullanım: `!sustur @kullanıcı <süre: 5m, 1h, 1d> [sebep]`\nÖrn: `!sustur @Ahmet 10m flood yapma`');
        return true;
      }
      const duration = parseDuration(args[2]) || (10 * 60 * 1000);
      const reason = args.slice(parseDuration(args[2]) ? 3 : 2).join(' ') || 'Yetkili tarafından susturuldu';
      
      const res = await timeoutUser(client, guildId, targetUserId, duration, reason, message.author);
      await message.reply(`🔇 <@${targetUserId}> kullanıcısı **${res.durationText}** süreyle susturuldu.\n📝 **Sebep:** ${reason}`);
      return true;
    }

    // 2. SUSTURMA KALDIRMA (!susturkaldir @kullanıcı)
    if (cmd === '!susturkaldir' || cmd === '!susturmakaldir' || cmd === '!untimeout' || cmd === '!unmute') {
      if (!targetUserId) {
        await message.reply('⚠️ Kullanım: `!susturkaldir @kullanıcı [sebep]`');
        return true;
      }
      const reason = args.slice(2).join(' ') || 'Susturma yetkili tarafından kaldırıldı';
      await untimeoutUser(client, guildId, targetUserId, reason, message.author);
      await message.reply(`🔊 <@${targetUserId}> kullanıcısının susturması kaldırıldı.`);
      return true;
    }

    // 3. SUNUCUDAN ATMA (!at @kullanıcı [sebep])
    if (cmd === '!at' || cmd === '!kick') {
      if (!targetUserId) {
        await message.reply('⚠️ Kullanım: `!at @kullanıcı [sebep]`\nÖrn: `!at @Ahmet kurallara uymadı`');
        return true;
      }
      const reason = args.slice(2).join(' ') || 'Yetkili tarafından sunucudan atıldı';
      await kickUser(client, guildId, targetUserId, reason, message.author);
      await message.reply(`👢 <@${targetUserId}> sunucudan atıldı.\n📝 **Sebep:** ${reason}`);
      return true;
    }

    // 4. YASAKLAMA (!yasakla @kullanıcı [sebep])
    if (cmd === '!yasakla' || cmd === '!ban') {
      if (!targetUserId) {
        await message.reply('⚠️ Kullanım: `!yasakla @kullanıcı [sebep]`\nÖrn: `!yasakla @Ahmet reklam yaptı`');
        return true;
      }
      const reason = args.slice(2).join(' ') || 'Yetkili tarafından yasaklandı';
      await banUser(client, guildId, targetUserId, reason, 1, message.author);
      await message.reply(`⛔ <@${targetUserId}> sunucudan yasaklandı.\n📝 **Sebep:** ${reason}`);
      return true;
    }

    // 5. YASAK KALDIRMA (!yasakkaldir <kullanıcıID> [sebep])
    if (cmd === '!yasakkaldir' || cmd === '!unban') {
      const rawId = args[1]?.replace(/[<@!>]/g, '');
      if (!rawId || !/^\d+$/.test(rawId)) {
        await message.reply('⚠️ Kullanım: `!yasakkaldir <kullanıcıID> [sebep]`\nÖrn: `!yasakkaldir 123456789 affedildi`');
        return true;
      }
      const reason = args.slice(2).join(' ') || 'Yasak kaldırıldı';
      await unbanUser(client, guildId, rawId, reason, message.author);
      await message.reply(`✅ \`${rawId}\` kimlikli kullanıcının yasağı kaldırıldı.`);
      return true;
    }

    // 6. MESAJ TEMİZLEME (!sil 20)
    if (cmd === '!sil' || cmd === '!temizle' || cmd === '!purge') {
      const count = parseInt(args[1], 10);
      if (isNaN(count) || count < 1 || count > 100) {
        await message.reply('⚠️ Lütfen 1 ile 100 arasında silinecek mesaj sayısı belirtin. Örn: `!sil 25`');
        return true;
      }
      const deleted = await purgeMessages(client, guildId, message.channelId, count, message.author);
      const confirmMsg = await message.reply(`🧹 **${deleted}** adet mesaj başarıyla silindi.`);
      setTimeout(() => {
        client.rest.deleteMessage(guildId, message.channelId, confirmMsg.id).catch(() => {});
      }, 5000);
      return true;
    }

    // 7. KANAL KİLİTLEME (!kilit [sebep])
    if (cmd === '!kilit' || cmd === '!lock') {
      const reason = args.slice(1).join(' ') || 'Sohbet yetkili tarafından kilitlendi';
      await lockChannel(client, guildId, message.channelId, reason, message.author);
      await message.reply(`🔒 **Bu kanal kilitlendi!** Üyelerin mesaj göndermesi geçici olarak kapatıldı.\n📝 **Sebep:** ${reason}`);
      return true;
    }

    // 8. KANAL KİLİDİ AÇMA (!kilitaç)
    if (cmd === '!kilitaç' || cmd === '!kilitac' || cmd === '!unlock') {
      await unlockChannel(client, guildId, message.channelId, message.author);
      await message.reply(`🔓 **Kanal kilidi açıldı!** Artık mesaj yazabilirsiniz.`);
      return true;
    }

    // 9. UYARI VERME (!uyar @kullanıcı [sebep])
    if (cmd === '!uyar' || cmd === '!warn') {
      if (!targetUserId) {
        await message.reply('⚠️ Kullanım: `!uyar @kullanıcı [sebep]`\nÖrn: `!uyar @Ahmet sohbette küfür`');
        return true;
      }
      const reason = args.slice(2).join(' ') || 'Kural ihlali';
      const result = await warnMember(client, guildId, targetUserId, reason, message.author);
      let replyText = `⚠️ <@${targetUserId}> kullanıcısına resmi uyarı verildi.\n📝 **Sebep:** ${reason}\n📊 **Toplam Uyarı:** ${result.warnCount}/5`;
      if (result.penaltyApplied) {
        replyText += `\n${result.penaltyApplied}`;
      }
      await message.reply(replyText);
      return true;
    }

    // 10. UYARILARI GÖRÜNTÜLEME (!uyarilar @kullanıcı)
    if (cmd === '!uyarilar' || cmd === '!warnings' || cmd === '!sicil') {
      const userToCheck = targetUserId || message.author.id;
      const list = getWarnings(guildId, userToCheck);
      if (!list.length) {
        await message.reply(`✨ <@${userToCheck}> kullanıcısının temiz bir sicili var, hiç uyarısı bulunmuyor.`);
        return true;
      }
      const warnLines = list.map((w, idx) => `**${idx + 1}.** ${w.reason} *(Yetkili: <@${w.moderatorId}> - ${new Date(w.date).toLocaleDateString('tr-TR')})*`);
      await message.reply(`📋 **<@${userToCheck}> Kullanıcısının Uyarı Sicili (${list.length}/5):**\n${warnLines.join('\n')}`);
      return true;
    }

    // 11. UYARILARI SİLME (!uyarisil @kullanıcı)
    if (cmd === '!uyarisil' || cmd === '!clearwarns') {
      if (!targetUserId) {
        await message.reply('⚠️ Kullanım: `!uyarisil @kullanıcı`');
        return true;
      }
      const deletedCount = clearWarnings(guildId, targetUserId);
      await message.reply(`✅ <@${targetUserId}> kullanıcısının **${deletedCount}** adet uyarısı silindi, sicili temizlendi.`);
      return true;
    }

    // 12. KORUMA / GÜVENLİK PANELİ (!koruma / !guvenlik)
    if (cmd === '!koruma' || cmd === '!guvenlik' || cmd === '!automod') {
      const s = getGuildSettings(guildId);
      const statusText = [
        '🛡️ **QUBIX v2.0.7 — SUNUCU GÜVENLİK PANELİ**',
        '',
        `🔗 **Anti-Link (Reklam Engelleme):** ${s.antiLink ? '✅ AÇIK' : '❌ KAPALI'} \`(!antilink ac/kapat)\``,
        `⚡ **Anti-Spam (Flood Koruması):** ${s.antiSpam ? '✅ AÇIK' : '❌ KAPALI'} \`(!antispam ac/kapat)\``,
        `🔠 **Anti-Caps (Büyük Harf Koruması):** ${s.antiCaps ? '✅ AÇIK' : '❌ KAPALI'} \`(!anticaps ac/kapat)\``,
        `📜 **Mod-Log Kanalı:** ${s.modLogChannelId ? `<#${s.modLogChannelId}>` : '❌ Ayarlanmamış'} \`(!modlog <#kanal>)\``,
        '',
        '💡 *Açıp kapatmak için yukarıdaki komutları kullanabilirsiniz.*'
      ].join('\n');
      await message.reply(statusText);
      return true;
    }

    // 13. ANTİ-LİNK TOGGLE (!antilink ac/kapat)
    if (cmd === '!antilink') {
      const mode = args[1]?.toLowerCase();
      const enable = mode === 'ac' || mode === 'aç' || mode === 'on' || mode === 'aktif';
      const disable = mode === 'kapat' || mode === 'off' || mode === 'pasif';
      if (!enable && !disable) {
        await message.reply('⚠️ Kullanım: `!antilink ac` veya `!antilink kapat`');
        return true;
      }
      updateGuildSettings(guildId, { antiLink: enable });
      await message.reply(`🔗 **Anti-Link (Reklam Koruması):** ${enable ? '✅ AKTİF EDİLDİ' : '❌ DEVRE DIŞI BIRAKILDI'}`);
      return true;
    }

    // 14. ANTİ-SPAM TOGGLE (!antispam ac/kapat)
    if (cmd === '!antispam') {
      const mode = args[1]?.toLowerCase();
      const enable = mode === 'ac' || mode === 'aç' || mode === 'on' || mode === 'aktif';
      const disable = mode === 'kapat' || mode === 'off' || mode === 'pasif';
      if (!enable && !disable) {
        await message.reply('⚠️ Kullanım: `!antispam ac` veya `!antispam kapat`');
        return true;
      }
      updateGuildSettings(guildId, { antiSpam: enable });
      await message.reply(`⚡ **Anti-Spam (Flood Koruması):** ${enable ? '✅ AKTİF EDİLDİ' : '❌ DEVRE DIŞI BIRAKILDI'}`);
      return true;
    }

    // 15. ANTİ-CAPS TOGGLE (!anticaps ac/kapat)
    if (cmd === '!anticaps') {
      const mode = args[1]?.toLowerCase();
      const enable = mode === 'ac' || mode === 'aç' || mode === 'on' || mode === 'aktif';
      const disable = mode === 'kapat' || mode === 'off' || mode === 'pasif';
      if (!enable && !disable) {
        await message.reply('⚠️ Kullanım: `!anticaps ac` veya `!anticaps kapat`');
        return true;
      }
      updateGuildSettings(guildId, { antiCaps: enable });
      await message.reply(`🔠 **Anti-Caps (Büyük Harf Koruması):** ${enable ? '✅ AKTİF EDİLDİ' : '❌ DEVRE DIŞI BIRAKILDI'}`);
      return true;
    }

    // 16. MOD-LOG KANALI AYARLAMA (!modlog <#kanal>)
    if (cmd === '!modlog') {
      const channelMatch = content.match(/<#!?(\d+)>/);
      if (!channelMatch) {
        await message.reply('⚠️ Kullanım: `!modlog <#kanal>` — Denetim günlüğünün gönderileceği kanalı etiketleyin.');
        return true;
      }
      const targetChId = channelMatch[1];
      updateGuildSettings(guildId, { modLogChannelId: targetChId });
      await message.reply(`📜 Moderasyon denetim günlüğü kanalı <#${targetChId}> olarak ayarlandı.`);
      return true;
    }

  } catch (err) {
    console.error('Moderasyon komutu hatası:', err);
    await message.reply(`⚠️ İşlem sırasında bir hata oluştu: ${err.message || 'Bilinmeyen hata'}`);
    return true;
  }

  return false;
}

/**
 * Doğal Dildeki Moderasyon İsteklerini Gerçekleştirir
 * "@Qubix Ahmet'i 10dk sustur küfür etti", "@Qubix bu kanalı kilitle" vb.
 */
async function handleNaturalModeration(client, guildId, message, cleanPrompt) {
  if (!guildId) return false;
  const modAction = parseNaturalModeration(cleanPrompt);
  if (!modAction) return false;

  const isMod = await checkModeratorPermission(client, guildId, message.member, message.author.id);
  if (!isMod) {
    await message.reply('🔒 Bu moderasyon işlemini gerçekleştirmek için yetkiniz bulunmuyor.');
    return true;
  }

  try {
    if (modAction.type === 'timeout') {
      if (!modAction.targetUserId) {
        await message.reply('⚠️ Susturulacak kullanıcıyı etiketlemeniz gerekiyor. Örn: `@Qubix @kullanıcı 10 dakika sustur`');
        return true;
      }
      const res = await timeoutUser(client, guildId, modAction.targetUserId, modAction.durationMs, modAction.reason, message.author);
      await message.reply(`🔇 <@${modAction.targetUserId}> kullanıcısı **${res.durationText}** süreyle susturuldu.\n📝 **Sebep:** ${modAction.reason}`);
      return true;
    }

    if (modAction.type === 'untimeout') {
      if (!modAction.targetUserId) {
        await message.reply('⚠️ Susturması kaldırılacak kullanıcıyı etiketleyin.');
        return true;
      }
      await untimeoutUser(client, guildId, modAction.targetUserId, 'Doğal dil komutuyla kaldırıldı', message.author);
      await message.reply(`🔊 <@${modAction.targetUserId}> kullanıcısının susturması kaldırıldı.`);
      return true;
    }

    if (modAction.type === 'kick') {
      if (!modAction.targetUserId) {
        await message.reply('⚠️ Sunucudan atılacak kullanıcıyı etiketleyin.');
        return true;
      }
      await kickUser(client, guildId, modAction.targetUserId, modAction.reason, message.author);
      await message.reply(`👢 <@${modAction.targetUserId}> sunucudan atıldı.\n📝 **Sebep:** ${modAction.reason}`);
      return true;
    }

    if (modAction.type === 'ban') {
      if (!modAction.targetUserId) {
        await message.reply('⚠️ Yasaklanacak kullanıcıyı etiketleyin.');
        return true;
      }
      await banUser(client, guildId, modAction.targetUserId, modAction.reason, 1, message.author);
      await message.reply(`⛔ <@${modAction.targetUserId}> sunucudan kalıcı olarak yasaklandı.\n📝 **Sebep:** ${modAction.reason}`);
      return true;
    }

    if (modAction.type === 'unban') {
      if (!modAction.targetUserId) {
        await message.reply('⚠️ Yasağı kaldırılacak kullanıcının ID numarasını belirtmelisiniz.');
        return true;
      }
      await unbanUser(client, guildId, modAction.targetUserId, 'Doğal dil komutuyla kaldırıldı', message.author);
      await message.reply(`✅ \`${modAction.targetUserId}\` kimlikli kullanıcının yasağı kaldırıldı.`);
      return true;
    }

    if (modAction.type === 'purge') {
      const channelId = modAction.targetChannelId || message.channelId;
      const deleted = await purgeMessages(client, guildId, channelId, modAction.amount, message.author);
      const replyMsg = await message.reply(`🧹 **${deleted}** adet mesaj temizlendi.`);
      setTimeout(() => {
        client.rest.deleteMessage(guildId, channelId, replyMsg.id).catch(() => {});
      }, 5000);
      return true;
    }

    if (modAction.type === 'lock') {
      const channelId = modAction.targetChannelId || message.channelId;
      await lockChannel(client, guildId, channelId, 'Kanal kilitlendi', message.author);
      await message.reply(`🔒 **Kanal kilitlendi!** Üyelerin yazması geçici olarak durduruldu.`);
      return true;
    }

    if (modAction.type === 'unlock') {
      const channelId = modAction.targetChannelId || message.channelId;
      await unlockChannel(client, guildId, channelId, message.author);
      await message.reply(`🔓 **Kanal kilidi açıldı!** Sohbet tekrar kullanıma açıldı.`);
      return true;
    }

    if (modAction.type === 'warn') {
      if (!modAction.targetUserId) {
        await message.reply('⚠️ Uyarılacak kullanıcıyı etiketleyin.');
        return true;
      }
      const res = await warnMember(client, guildId, modAction.targetUserId, modAction.reason, message.author);
      let text = `⚠️ <@${modAction.targetUserId}> kullanıcısına uyarı verildi.\n📝 **Sebep:** ${modAction.reason}\n📊 **Toplam Uyarı:** ${res.warnCount}/5`;
      if (res.penaltyApplied) text += `\n${res.penaltyApplied}`;
      await message.reply(text);
      return true;
    }
  } catch (err) {
    console.error('Doğal dil moderasyon hatası:', err);
    await message.reply(`⚠️ Moderasyon işlemi sırasında hata oluştu: ${err.message || 'Bilinmeyen hata'}`);
    return true;
  }

  return false;
}

// Bot istemcisi
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
});

// Bekleyen sunucu planları (guildId -> { plan, authorId, timeoutTimer })
const pendingPlans = new Map();

client.on('ready', () => {
  console.log(`\n======================================================`);
  console.log(`🤖 QUBIX v2.0.7: AI Sohbet + Sunucu Mimarı + MODERASYON AKTİF!`);
  console.log(`✅ Giriş Yapılan Hesap: ${client.user.username} (ID: ${client.user.id})`);
  console.log(`🛡️ Auto-Mod, Ceza Sistemi ve Doğal Dil Moderasyonu Hazır!`);
  console.log(`======================================================\n`);
});

/**
 * Kullanıcının sunucu düzenleme yetkisi (Sahip veya Yönetici) olup olmadığını kesin olarak doğrular.
 */
async function checkServerPermission(client, guildId, member, authorId) {
  const authIdStr = String(authorId || '');
  const memberUserIdStr = String(member?.user_id || member?.id || '');

  // 1. Üye nesnesinde doğrudan isOwner kontrolü
  if (member?.isOwner === true || member?.is_owner === true) {
    return true;
  }

  // 2. Sunucu sahibini doğrudan API veya cache üzerinden kontrol et
  try {
    let guild = client.guilds?.get?.(guildId);
    let ownerId = guild?.ownerId || guild?.owner_id;

    if (!ownerId) {
      const apiGuild = await client.rest.getGuild(guildId);
      ownerId = apiGuild?.owner_id || apiGuild?.ownerId;
    }

    if (ownerId && (String(ownerId) === authIdStr || String(ownerId) === memberUserIdStr)) {
      return true;
    }
  } catch (err) {
    console.warn('Sunucu bilgisi kontrol uyarısı:', err.message);
  }

  // 3. İzin kontrolü (Administrator veya ManageChannels)
  if (member?.permissions) {
    if (typeof member.permissions.has === 'function') {
      if (member.permissions.has('Administrator') || member.permissions.has('ManageChannels') || member.permissions.has('ManageGuild')) {
        return true;
      }
    }
    const pBits = BigInt(member.permissions.bits || member.permissions || 0);
    const adminBit = 1n << 3n;         // 8n
    const manageChannelsBit = 1n << 4n; // 16n
    if ((pBits & adminBit) !== 0n || (pBits & manageChannelsBit) !== 0n) {
      return true;
    }
  }

  // 4. API'den üye bilgisini teyit et
  try {
    const apiMember = await client.rest.getMember(guildId, authorId);
    if (apiMember?.isOwner || apiMember?.is_owner) return true;
    if (apiMember?.permissions) {
      const pBits = BigInt(apiMember.permissions);
      const adminBit = 1n << 3n;
      const manageChannelsBit = 1n << 4n;
      if ((pBits & adminBit) !== 0n || (pBits & manageChannelsBit) !== 0n) {
        return true;
      }
    }
  } catch (err) {
    console.warn('API üye yetki teyit uyarısı:', err.message);
  }

  return false;
}

/**
 * Kullanıcının moderasyon yapma yetkisi (Yönetici, Moderatör veya Sunucu Sahibi) olup olmadığını doğrular.
 */
async function checkModeratorPermission(client, guildId, member, authorId) {
  // Önce tam sunucu yönetici yetkisini kontrol et
  const isServerAdmin = await checkServerPermission(client, guildId, member, authorId);
  if (isServerAdmin) return true;

  // Moderasyon izin bitleri: Kick(2n), Ban(4n), ManageMessages(8192n), ModerateMembers(1099511627776n)
  const modBits = (1n << 1n) | (1n << 2n) | (1n << 13n) | (1n << 40n);

  if (member?.permissions) {
    if (typeof member.permissions.has === 'function') {
      if (
        member.permissions.has('KickMembers') ||
        member.permissions.has('BanMembers') ||
        member.permissions.has('ManageMessages') ||
        member.permissions.has('ModerateMembers')
      ) {
        return true;
      }
    }
    const pBits = BigInt(member.permissions.bits || member.permissions || 0);
    if ((pBits & modBits) !== 0n) return true;
  }

  try {
    const apiMember = await client.rest.getMember(guildId, authorId);
    if (apiMember?.isOwner || apiMember?.is_owner) return true;
    if (apiMember?.permissions) {
      const pBits = BigInt(apiMember.permissions);
      if ((pBits & modBits) !== 0n) return true;
    }
  } catch (_) {}

  return false;
}

/**
 * Onaylanan planı uygular ve sonucu bildirir.
 */
async function processPlanConfirmation(guildId, user, sendReply) {
  const pending = pendingPlans.get(guildId);
  if (!pending) {
    await sendReply('⚠️ Şu anda onay bekleyen aktif bir sunucu mimarlık planı bulunmuyor.');
    return;
  }

  clearTimeout(pending.timeoutTimer);
  pendingPlans.delete(guildId);

  await sendReply('🔨 **İnşaat başladı!** Odalar, kategoriler ve roller oluşturuluyor, lütfen birkaç saniye bekle...');

  const results = await executeServerPlan(client, guildId, pending.plan);

  const report = [
    results.errors.length === 0
      ? '🎉 **İşlem başarıyla tamamlandı.**'
      : '⚠️ **İşlem kısmen tamamlandı veya başarısız oldu.**',
    '',
  ];

  if (results.categoriesCreated.length > 0) {
    report.push('📁 **Oluşturulan Kategoriler:**');
    results.categoriesCreated.forEach(c => report.push(`  • ${c}`));
    report.push('');
  }

  if (results.channelsCreated.length > 0) {
    report.push('💬 **Oluşturulan Kanallar:**');
    results.channelsCreated.forEach(ch => report.push(`  • ${ch}`));
    report.push('');
  }

  if (results.rolesCreated.length > 0) {
    report.push('🏷️ **Oluşturulan Roller:**');
    results.rolesCreated.forEach(r => report.push(`  • ${r}`));
    report.push('');
  }

  if (results.messagesPinned.length > 0) {
    report.push('📌 **Mesaj gönderilip sabitlenen kanallar:**');
    results.messagesPinned.forEach(channel => report.push(`  • ${channel}`));
    report.push('');
  }

  if (results.errors.length > 0) {
    report.push('⚠️ **Bazı işlemler sırasında hata oluştu:**');
    results.errors.forEach(e => report.push(`  • ${e}`));
    report.push('');
  }

  report.push('Sunucun artık yeni haliyle kullanıma hazır! Başka bir isteğin olursa buradayım. ✨');

  await sendReply(report.join('\n'));
}

// Buton etkileşimlerini dinle
client.on('interactionCreate', async (interaction) => {
  try {
    if (!interaction.isButton()) return;

    const guildId = interaction.guildId;
    if (!guildId) return;

    const pending = pendingPlans.get(guildId);
    if (!pending) {
      await interaction.reply({ content: '⚠️ Bu planın süresi dolmuş veya daha önce işlenmiş.', ephemeral: true });
      return;
    }

    const hasPerm = await checkServerPermission(client, guildId, interaction.member, interaction.user.id);
    if (!hasPerm) {
      await interaction.reply({ content: '🔒 Bu planı onaylama yetkiniz bulunmuyor.', ephemeral: true });
      return;
    }

    if (interaction.customId === 'confirm_server_plan') {
      await interaction.deferReply();
      await processPlanConfirmation(guildId, interaction.user, async (msg) => {
        await interaction.followUp(msg);
      });
    } else if (interaction.customId === 'cancel_server_plan') {
      clearTimeout(pending.timeoutTimer);
      pendingPlans.delete(guildId);
      await interaction.reply('❌ Sunucu düzenleme planı iptal edildi. Hiçbir değişiklik yapılmadı.');
    }
  } catch (err) {
    console.error('Interaction hatası:', err);
  }
});

// Mesajları dinle
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const content = message.content ? message.content.trim() : '';
  if (!content) return;

  const guildId = message.guildId;

  // 0. Otomatik Moderasyon Denetimi (Anti-Link, Anti-Spam, Anti-Caps)
  if (guildId) {
    const isMod = await checkModeratorPermission(client, guildId, message.member, message.author.id);
    const isBlocked = await checkAutoMod(client, message, isMod);
    if (isBlocked) return;
  }

  // 1. Klasik Moderasyon Komutları (!sustur, !at, !yasakla, !sil, !kilit, !uyar, !koruma vb.)
  if (guildId) {
    const isHandledMod = await handleModerationCommands(client, message, content, guildId);
    if (isHandledMod) return;
  }

  // 2. Hızlı Onay / İptal Metin Komutları
  if (guildId && (content === '!onayla' || content.toLowerCase() === 'onayla')) {
    if (pendingPlans.has(guildId)) {
      const hasPerm = await checkServerPermission(client, guildId, message.member, message.author.id);
      if (!hasPerm) {
        await message.reply('🔒 Bu planı onaylama yetkiniz bulunmuyor.');
        return;
      }
      await processPlanConfirmation(guildId, message.author, async (msg) => {
        await message.reply(msg);
      });
      return;
    }
  }

  if (guildId && (content === '!iptal' || content.toLowerCase() === 'iptal')) {
    if (pendingPlans.has(guildId)) {
      const pending = pendingPlans.get(guildId);
      clearTimeout(pending.timeoutTimer);
      pendingPlans.delete(guildId);
      await message.reply('❌ Sunucu mimarlık planı iptal edildi. Hiçbir değişiklik yapılmadı.');
      return;
    }
  }

  // 3. Ping Testi
  if (content === '!ping') {
    await message.reply('🏓 Pong! Qubix ve tüm yapay zeka & moderasyon modülleri sorunsuz çalışıyor.');
    return;
  }

  // 4. Yardım Menüsü (v2.0.7)
  if (content === '!yardim' || content === '!help') {
    const help = [
      '👋 **Merhaba! Ben Qubix (v2.0.7) — Jubbio Asistanı, Sunucu Mimarı ve Baş Moderatörü.**',
      '',
      '🧠 **1. Mod: Yapay Zeka Sohbet & Bilim:**',
      '• `@Qubix Kuantum fiziği nedir?` veya `!soru <soru>`',
      '• `Qubix, bana moral verecek bir söz söyle` *(Kanal hafızası aktiftir!)*',
      '',
      '🛠️ **2. Mod: Akıllı Sunucu Mimarı & Rol Yönetimi:**',
      '• `@Qubix bana bir yazılım topluluğu sunucusu kur`',
      '• `@Qubix oyun odaları, ses kanalları ve VIP rolü oluştur`',
      '• `@Qubix rol oluştur Moderatör` (kırmızı, mavi, yeşil vb.)',
      '• `@Qubix <@kullanıcı> Moderatör rolü ver / al`',
      '',
      '🛡️ **3. Mod: Gelişmiş Moderasyon & Ceza:**',
      '• `!sustur @kullanıcı 10m [sebep]` *(veya @Qubix Ahmet\'i 10dk sustur)*',
      '• `!susturkaldir @kullanıcı` *(susturmayı kaldırır)*',
      '• `!at @kullanıcı [sebep]` / `!yasakla @kullanıcı [sebep]`',
      '• `!sil <1-100>` *(sohbeti topluca temizler)*',
      '• `!kilit` / `!kilitaç` *(kanala mesaj yazmayı kilitler/açar)*',
      '• `!uyar @kullanıcı [sebep]` *(3 uyarıda 1 saat susturma, 5 uyarıda atılma!)*',
      '• `!uyarilar @kullanıcı` / `!uyarisil @kullanıcı`',
      '',
      '🚨 **4. Mod: Otomatik Koruma (Auto-Mod):**',
      '• `!koruma` *(Güvenlik kontrol panelini açar)*',
      '• `!antilink ac/kapat` *(İzinsiz reklam ve linkleri anında engeller)*',
      '• `!antispam ac/kapat` *(Flood ve spam yapanları otomatik susturur)*',
      '• `!modlog <#kanal>` *(Bütün ceza işlemlerini log kanalına kaydeder)*',
      '',
      '✨ *Tüm moderasyon işlemlerini serbest Türkçe doğal dilde de bana iletebilirsin!*',
    ].join('\n');
    await message.reply(help);
    return;
  }

  // 4. Qubix'i Tetikleme Algılama
  const botUserId = String(client.user?.id || '');
  const botAppId = String(client.applicationId || '');
  const contentLower = content.toLowerCase();

  const hasMentionTag = (botUserId && content.includes(`<@${botUserId}>`)) ||
                        (botAppId && content.includes(`<@${botAppId}>`));

  const hasNameMention = contentLower.startsWith('@qubix') || 
                         contentLower.includes('@qubix') ||
                         contentLower.startsWith('qubix');

  const hasMentionObj = message.mentions?.users?.some(u => 
    String(u.id) === botUserId || String(u.id) === botAppId
  );

  const isMentioned = hasMentionTag || hasNameMention || hasMentionObj;
  const isSoruCommand = content.startsWith('!soru ') || content.startsWith('!ai ') || content.startsWith('!q ') || content.startsWith('!mimar ');
  const isDM = !guildId;

  if (!isMentioned && !isSoruCommand && !isDM) return;

  // Soruyu temizle
  let cleanPrompt = content;
  if (botUserId) cleanPrompt = cleanPrompt.replaceAll(`<@${botUserId}>`, '').replaceAll(`<@!${botUserId}>`, '');
  if (botAppId) cleanPrompt = cleanPrompt.replaceAll(`<@${botAppId}>`, '').replaceAll(`<@!${botAppId}>`, '');
  cleanPrompt = cleanPrompt.replace(/@qubix/gi, '');

  if (cleanPrompt.toLowerCase().startsWith('qubix')) {
    cleanPrompt = cleanPrompt.slice(5).replace(/^[,:\s]+/, '');
  }

  if (content.startsWith('!soru ')) cleanPrompt = content.slice(6);
  if (content.startsWith('!ai ')) cleanPrompt = content.slice(4);
  if (content.startsWith('!q ')) cleanPrompt = content.slice(3);
  if (content.startsWith('!mimar ')) cleanPrompt = content.slice(7);

  cleanPrompt = cleanPrompt.trim();
  if (!cleanPrompt) {
    await message.reply('Seni dinliyorum! Bana bir soru sorabilir veya sunucun için bir mimarlık isteği iletebilirsin.');
    return;
  }

  if (guildId) {
    // Doğal Dil Moderasyon İstekleri (örn: "@Qubix Ahmet'i 10dk sustur", "@Qubix bu kanalı kilitle")
    const isNaturalMod = await handleNaturalModeration(client, guildId, message, cleanPrompt);
    if (isNaturalMod) return;

    const isRoleAction = /(rol|role|yetki)/i.test(cleanPrompt) && /(oluştur|yarat|aç|ekle|düzenle|güncelle|değiştir|ver|al|kaldır|kanal|özel)/i.test(cleanPrompt);
    if (isRoleAction) {
      const handled = await handleRoleManagementRequest(client, guildId, message, cleanPrompt);
      if (handled) return;
    }
  }

  console.log(`📩 [${message.author.username}] Gelen İstek: "${cleanPrompt}"`);

  // Sunucu ortamında ise önce mimarlık isteği mi kontrol et
  if (guildId) {
    let guild = client.guilds.get(guildId);
    if (!guild) {
      try {
        guild = await client.rest.getGuild(guildId);
      } catch (_) {}
    }
    const serverName = guild?.name || 'Jubbio Sunucusu';
    const channelHistory = await getChannelHistory(client, guildId, message.channelId);
    let availableChannels = [];
    try {
      const guildChannels = await client.rest.getGuildChannels(guildId);
      const channelList = Array.isArray(guildChannels)
        ? guildChannels
        : guildChannels?.channels || guildChannels?.data || guildChannels?.items || [];
      const normalizedChannelList = Array.isArray(channelList)
        ? channelList
        : Object.values(channelList || {});
      availableChannels = normalizedChannelList
        .filter(channel => channel && channel.id)
        .map(channel => ({
            id: String(channel.id),
            name: channel.name || 'isimsiz-kanal',
            type: Number(channel.type),
          }));
    } catch (err) {
      console.warn('Kanal listesi alınamadı:', err.message);
    }

    const requestedChannelIds = [...cleanPrompt.matchAll(/<#!?(\d+)>/g)].map(match => match[1]);
    const requestedChannels = requestedChannelIds
      .map(channelId => availableChannels.find(channel => channel.id === channelId) || {
        id: channelId,
        name: `kanal-${channelId}`,
        type: 0,
      });
    const wantsChannelMessages = isExplicitChannelMessageRequest(cleanPrompt) && requestedChannels.length > 0 && !/(rol|role|yetki|izin|düzenle|güncelle|değiştir|özel rol)/i.test(cleanPrompt);
    const customChannelMessage = extractCustomChannelMessage(cleanPrompt);

    // Açık kanal etiketleri varsa bu işlem için AI çağrısı gerekmez.
    let analysis;
    if (wantsChannelMessages && requestedChannels.length > 0) {
      analysis = {
        type: 'architect',
        summary: `${requestedChannels.length} mevcut kanala kullanım mesajı gönderilecek ve sabitlenecek.`,
        existingChannelMessages: requestedChannels.map(channel => ({
          channelId: channel.id,
          channelName: channel.name,
          content: customChannelMessage || createChannelGuide(channel.name),
        })),
      };
    } else {
      // Yapay zeka ile niyeti ve yapılabilirliği analiz et
      analysis = await analyzeServerRequest(cleanPrompt, serverName, availableChannels, channelHistory);
    }

    // Mevcut kanal etiketleri açıkça verildiyse bu operasyonu doğrudan plana al.
    if (wantsChannelMessages && requestedChannels.length > 0) {
      const generatedMessages = Array.isArray(analysis.existingChannelMessages)
        ? analysis.existingChannelMessages
        : Array.isArray(analysis.channelMessages) ? analysis.channelMessages : [];

      analysis.type = 'architect';
      analysis.summary = `${requestedChannels.length} mevcut metin kanalına kullanım mesajı gönderilecek ve sabitlenecek.`;
      analysis.existingChannelMessages = requestedChannels.map(channel => {
        const generated = generatedMessages.find(item =>
          String(item?.channelId || '') === channel.id || item?.channelName === channel.name
        );
        const finalContent = customChannelMessage || generated?.content || createChannelGuide(channel.name);
        if (customChannelMessage) {
          console.log(`📣 Kullanıcıya özel kanal mesajı kullanıldı: "${customChannelMessage.slice(0, 120)}"`);
        }
        return {
          channelId: channel.id,
          channelName: channel.name,
          content: finalContent,
        };
      });
    }

    // DURUM 1: İmkansız / Kural Dışı İstek
    if (analysis.type === 'impossible') {
      console.log(`🚫 İmkansız İstek Engellendi: ${analysis.message}`);
      await message.reply(`⛔ **İşlem Gerçekleştirilemez:**\n${analysis.message}`);
      return;
    }

    // DURUM 2: Jubbio'da Doğrudan Olmayan Ama Alternatifi Olan İstek
    if (analysis.type === 'workaround') {
      console.log(`💡 Alternatif Yan Yol Sunuldu: ${analysis.message}`);
      await message.reply(`💡 **Alternatif Çözüm:**\n${analysis.message}`);
      return;
    }

    // DURUM 3: Yapılabilir Sunucu Mimarlık İsteği
    if (analysis.type === 'architect') {
      // Kesin yetki kontrolü
      const hasPerm = await checkServerPermission(client, guildId, message.member, message.author.id);
      if (!hasPerm) {
        await message.reply('🔒 **Yetki Yetersiz:** Sunucu kanallarını ve rollerini düzenleme işlemlerini yalnızca sunucu sahibi veya yöneticileri talep edebilir.');
        return;
      }

      console.log(`📋 [${message.author.username}] İçin Mimarlık Planı Hazırlandı:`, analysis.summary);

      // Plan mesajını oluştur
      const planLines = [
        '📋 **Qubix Sunucu Mimarlık Planı:**',
        `${analysis.summary}`,
        '',
      ];

      if (analysis.categories && analysis.categories.length > 0) {
        planLines.push('📁 **Planlanan Kategoriler ve Kanallar:**');
        analysis.categories.forEach(cat => {
          planLines.push(`• **${cat.name}**`);
          if (cat.channels && cat.channels.length > 0) {
            cat.channels.forEach(ch => {
              planLines.push(`    └ ${ch.type === 'voice' ? '🔊' : '💬'} #${ch.name}`);
            });
          }
        });
        planLines.push('');
      }

      if (analysis.standaloneChannels && analysis.standaloneChannels.length > 0) {
        planLines.push('💬 **Bağımsız Kanallar:**');
        analysis.standaloneChannels.forEach(ch => {
          planLines.push(`  • ${ch.type === 'voice' ? '🔊' : '💬'} #${ch.name}`);
        });
        planLines.push('');
      }

      if (analysis.roles && analysis.roles.length > 0) {
        planLines.push('🏷️ **Planlanan Roller:**');
        analysis.roles.forEach(r => {
          planLines.push(`  • @${r.name}`);
        });
        planLines.push('');
      }

      if (analysis.existingChannelMessages && analysis.existingChannelMessages.length > 0) {
        planLines.push('📌 **Mevcut kanallara gönderilecek ve sabitlenecek mesajlar:**');
        analysis.existingChannelMessages.forEach(item => {
          planLines.push(`  • #${item.channelName}`);
        });
        planLines.push('');
      }

      planLines.push('⚠️ **Onayınız Gerekiyor:**');
      planLines.push('Bu planı sunucuna uygulamamı onaylıyor musun?');
      planLines.push('Aşağıdaki butona tıklayabilir veya sohbete **`!onayla`** yazabilirsin.');
      planLines.push('*(İptal etmek için `!iptal` yazabilirsin. Süre: 2 dakika)*');

      // 2 dakikalık otomatik iptal zamanlayıcısı
      const timer = setTimeout(() => {
        if (pendingPlans.has(guildId)) {
          pendingPlans.delete(guildId);
          message.reply('⏳ Onay süresi (2 dakika) dolduğu için sunucu mimarlık planı zaman aşımına uğradı.').catch(() => {});
        }
      }, 120000);

      pendingPlans.set(guildId, {
        plan: analysis,
        authorId: message.author.id,
        timeoutTimer: timer,
      });

      // Butonları oluştur
      const confirmButton = new ButtonBuilder()
        .setCustomId('confirm_server_plan')
        .setLabel('Onayla ve İnşa Et 🚀')
        .setStyle(ButtonStyle.Success);

      const cancelButton = new ButtonBuilder()
        .setCustomId('cancel_server_plan')
        .setLabel('İptal Et ❌')
        .setStyle(ButtonStyle.Danger);

      const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

      try {
        await message.reply({
          content: planLines.join('\n'),
          components: [row],
        });
      } catch (sendErr) {
        await message.reply(planLines.join('\n'));
      }
      return;
    }
  }

  // DURUM 4: Normal Sohbet / Soru (1. Mod)
  console.log(`🤔 [${message.author.username}] Sohbet sorusu yanıtlanıyor: "${cleanPrompt}"`);
  try {
    const channelHistory = guildId
      ? await getChannelHistory(client, guildId, message.channelId)
      : [];
    const answer = await askGemini(cleanPrompt, message.author.username, channelHistory);
    if (!message.guildId && !message.channelId) {
      console.warn('⚠️ guildId/channelId eksik, yanıt gönderilemedi.');
      return;
    }
    if (answer.length <= 1900) {
      await message.reply(answer);
    } else {
      const parts = answer.match(/[\s\S]{1,1900}/g) || [answer];
      for (let i = 0; i < parts.length; i++) {
        if (i > 0) await sleep(1100);
        await message.reply(parts[i]);
      }
    }
    console.log(`✅ [${message.author.username}] Sohbet yanıtı gönderildi.`);
  } catch (err) {
    console.error('Sohbet yanıtı hatası:', err);
    try {
      if (message.guildId || message.channelId) {
        await message.reply('Cevap üretirken bir sorunla karşılaştım, lütfen az sonra tekrar dener misin?');
      }
    } catch (_) {
      // Yanıt gönderilemedi, sessizce geç
    }
  }
});

// Yakalanmayan hataları yakala – bot çökmesin
process.on('uncaughtException', (err) => {
  console.error('❌ Yakalanmayan Hata (bot çalışmaya devam ediyor):', err.message);
});

process.on('unhandledRejection', (reason) => {
  console.error('❌ İşlenmeyen Promise Reddi (bot çalışmaya devam ediyor):', reason);
});

// Botu başlat
const botToken = process.env.BOT_TOKEN?.trim();
if (!botToken) {
  throw new Error('BOT_TOKEN tanımlı değil. .env.example dosyasını .env olarak kopyalayıp bot tokenını ekleyin.');
}

client.login(botToken);
