import fs from 'fs';
import path from 'path';

const DATA_DIR = './data';
const WARNINGS_FILE = path.join(DATA_DIR, 'warnings.json');
const GUILD_SETTINGS_FILE = path.join(DATA_DIR, 'guild-settings.json');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Veri dizinini garantiye al
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Yardımcı: JSON oku/yaz
function readJSON(file, defaultValue = {}) {
  try {
    if (!fs.existsSync(file)) return defaultValue;
    const content = fs.readFileSync(file, 'utf8');
    return JSON.parse(content || '{}');
  } catch (err) {
    console.warn(`⚠️ ${file} okunamadı:`, err.message);
    return defaultValue;
  }
}

function writeJSON(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error(`❌ ${file} yazılamadı:`, err.message);
  }
}

/**
 * Süre metnini (5m, 10dk, 1h, 2 saat, 1d, 3 gün vb.) milisaniyeye çevirir.
 * @param {string} str - Süre ifadesi
 * @returns {number|null} - Milisaniye cinsinden süre veya null
 */
export function parseDuration(str) {
  if (!str) return null;
  const normalized = String(str).trim().toLowerCase();

  // Standart kısaltmalar: 30s, 10m, 2h, 1d, 1w
  const standardMatch = normalized.match(/^(\d+)\s*(s|m|h|d|w|dk|sn|saat|gun|gün|hafta)$/i);
  if (standardMatch) {
    const val = parseInt(standardMatch[1], 10);
    const unit = standardMatch[2].toLowerCase();
    switch (unit) {
      case 's':
      case 'sn':
        return val * 1000;
      case 'm':
      case 'dk':
        return val * 60 * 1000;
      case 'h':
      case 'saat':
        return val * 60 * 60 * 1000;
      case 'd':
      case 'gun':
      case 'gün':
        return val * 24 * 60 * 60 * 1000;
      case 'w':
      case 'hafta':
        return val * 7 * 24 * 60 * 60 * 1000;
    }
  }

  // Cümle içi eşleşme (örn: "15 dakika", "1 saat", "2 gün")
  const sentenceMatch = normalized.match(/(\d+)\s*(saniye|dakika|saat|gün|gun|hafta)/i);
  if (sentenceMatch) {
    const val = parseInt(sentenceMatch[1], 10);
    const unit = sentenceMatch[2].toLowerCase();
    if (unit.startsWith('san')) return val * 1000;
    if (unit.startsWith('dak')) return val * 60 * 1000;
    if (unit.startsWith('saa')) return val * 60 * 60 * 1000;
    if (unit.startsWith('g')) return val * 24 * 60 * 60 * 1000;
    if (unit.startsWith('haf')) return val * 7 * 24 * 60 * 60 * 1000;
  }

  return null;
}

/**
 * Milisaniyeyi okunabilir Türkçe süreye dönüştürür.
 */
export function formatDuration(ms) {
  if (!ms || ms <= 0) return '0 saniye';
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days} gün`;
  if (hours > 0) return `${hours} saat`;
  if (minutes > 0) return `${minutes} dakika`;
  return `${seconds} saniye`;
}

// ==========================================
// 1. SUNUCU AYARLARI VE MOD-LOG YÖNETİMİ
// ==========================================

export function getGuildSettings(guildId) {
  const all = readJSON(GUILD_SETTINGS_FILE, {});
  return all[guildId] || {
    antiLink: false,
    antiSpam: false,
    antiCaps: false,
    modLogChannelId: null,
  };
}

export function updateGuildSettings(guildId, newSettings) {
  const all = readJSON(GUILD_SETTINGS_FILE, {});
  all[guildId] = { ...(all[guildId] || {}), ...newSettings };
  writeJSON(GUILD_SETTINGS_FILE, all);
  return all[guildId];
}

/**
 * Moderasyon işlemlerini log kanalına bildirir.
 */
export async function logModerationAction(client, guildId, { action, moderator, target, reason, details }) {
  try {
    const settings = getGuildSettings(guildId);
    let logChannelId = settings.modLogChannelId;

    // Eğer log kanalı ayarlanmamışsa, sunucudaki #mod-log veya #ceza-takip kanalını otomatik ara
    if (!logChannelId) {
      try {
        const channels = await client.rest.getGuildChannels(guildId);
        const list = Array.isArray(channels) ? channels : channels?.channels || [];
        const found = list.find((ch) =>
          ch.name && /(mod[-_]?log|ceza[-_]?takip|denetim[-_]?kaydi|moderasyon[-_]?log)/i.test(ch.name)
        );
        if (found) logChannelId = found.id;
      } catch (_) {}
    }

    if (!logChannelId) return; // Log kanalı yoksa sessizce geç

    const timestamp = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    const logMessage = [
      `🛡️ **[MODERASYON GÜNLÜĞÜ] — ${action.toUpperCase()}**`,
      `👤 **Kullanıcı:** ${target ? `<@${target.id || target}>` : 'Belirtilmedi'} (${target?.username || target?.id || target})`,
      `👮 **Yetkili:** <@${moderator?.id || moderator}> (${moderator?.username || 'Yetkili'})`,
      reason ? `📝 **Sebep:** ${reason}` : null,
      details ? `ℹ️ **Detay:** ${details}` : null,
      `⏰ **Zaman:** ${timestamp}`,
    ]
      .filter(Boolean)
      .join('\n');

    await sleep(600);
    await client.rest.createMessage(guildId, logChannelId, { content: logMessage });
  } catch (err) {
    console.warn('Mod-log gönderilemedi:', err.message);
  }
}

// ==========================================
// 2. KULLANICI CEZA İŞLEMLERİ
// ==========================================

/**
 * Kullanıcıyı süreli susturur (Timeout)
 */
export async function timeoutUser(client, guildId, userId, durationMs, reason = 'Yetkili tarafından susturuldu', moderator = null) {
  await client.rest.timeoutMember(guildId, userId, durationMs, reason);
  await logModerationAction(client, guildId, {
    action: 'Susturma (Timeout)',
    moderator,
    target: userId,
    reason,
    details: `Süre: ${formatDuration(durationMs)}`,
  });
  return { success: true, durationText: formatDuration(durationMs) };
}

/**
 * Kullanıcının susturmasını kaldırır
 */
export async function untimeoutUser(client, guildId, userId, reason = 'Susturma yetkili tarafından kaldırıldı', moderator = null) {
  await client.rest.timeoutMember(guildId, userId, null, reason);
  await logModerationAction(client, guildId, {
    action: 'Susturma Kaldırıldı',
    moderator,
    target: userId,
    reason,
  });
  return { success: true };
}

/**
 * Kullanıcıyı sunucudan atar (Kick)
 */
export async function kickUser(client, guildId, userId, reason = 'Yetkili tarafından atıldı', moderator = null) {
  await client.rest.kickMember(guildId, userId, reason);
  await logModerationAction(client, guildId, {
    action: 'Sunucudan Atma (Kick)',
    moderator,
    target: userId,
    reason,
  });
  return { success: true };
}

/**
 * Kullanıcıyı sunucudan yasaklar (Ban)
 */
export async function banUser(client, guildId, userId, reason = 'Yetkili tarafından yasaklandı', deleteDays = 1, moderator = null) {
  await client.rest.banMember(guildId, userId, {
    reason,
    deleteMessageDays: deleteDays,
  });
  await logModerationAction(client, guildId, {
    action: 'Yasaklama (Ban)',
    moderator,
    target: userId,
    reason,
    details: `Son ${deleteDays} günün mesajları temizlendi`,
  });
  return { success: true };
}

/**
 * Kullanıcının yasağını kaldırır (Unban)
 */
export async function unbanUser(client, guildId, userId, reason = 'Yasak kaldırıldı', moderator = null) {
  await client.rest.unbanMember(guildId, userId, reason);
  await logModerationAction(client, guildId, {
    action: 'Yasak Kaldırıldı (Unban)',
    moderator,
    target: userId,
    reason,
  });
  return { success: true };
}

// ==========================================
// 3. AKILLI UYARI (WARN) VE SİCİL SİSTEMİ
// ==========================================

/**
 * Kullanıcıya uyarı ekler ve gerekirse otomatik yaptırım uygular.
 * 3. uyarı: 1 saat susturma
 * 5. uyarı: sunucudan atma
 */
export async function warnMember(client, guildId, userId, reason = 'Kural ihlali', moderator = null) {
  const allWarnings = readJSON(WARNINGS_FILE, {});
  const guildKey = String(guildId);
  const userKey = String(userId);

  if (!allWarnings[guildKey]) allWarnings[guildKey] = {};
  if (!allWarnings[guildKey][userKey]) allWarnings[guildKey][userKey] = [];

  const newWarning = {
    id: allWarnings[guildKey][userKey].length + 1,
    reason,
    moderatorId: moderator?.id || String(moderator || 'Sistem'),
    date: new Date().toISOString(),
  };

  allWarnings[guildKey][userKey].push(newWarning);
  writeJSON(WARNINGS_FILE, allWarnings);

  const warnCount = allWarnings[guildKey][userKey].length;
  let penaltyApplied = null;

  // Otomatik Kademeli Yaptırım
  try {
    if (warnCount === 3) {
      // 3. uyarıda 1 saat susturma
      const oneHour = 60 * 60 * 1000;
      await timeoutUser(client, guildId, userId, oneHour, '3 adet uyarı aldığı için otomatik susturuldu', { username: 'Qubix Auto-Mod' });
      penaltyApplied = '🚨 Kullanıcı 3 uyarıya ulaştığı için **1 saat susturuldu!**';
    } else if (warnCount >= 5) {
      // 5. uyarıda sunucudan atılma
      await kickUser(client, guildId, userId, '5 adet uyarı limitine ulaştığı için sunucudan atıldı', { username: 'Qubix Auto-Mod' });
      penaltyApplied = '⛔ Kullanıcı 5 uyarıya ulaştığı için **sunucudan atıldı!**';
    }
  } catch (err) {
    console.error('Otomatik uyarı yaptırımı hatası:', err.message);
  }

  await logModerationAction(client, guildId, {
    action: 'Uyarı (Warn)',
    moderator,
    target: userId,
    reason,
    details: `Toplam Uyarı: ${warnCount}/5 ${penaltyApplied ? `— ${penaltyApplied}` : ''}`,
  });

  return {
    warnCount,
    warning: newWarning,
    penaltyApplied,
  };
}

/**
 * Kullanıcının uyarı geçmişini getirir.
 */
export function getWarnings(guildId, userId) {
  const allWarnings = readJSON(WARNINGS_FILE, {});
  return allWarnings[String(guildId)]?.[String(userId)] || [];
}

/**
 * Kullanıcının uyarılarını temizler.
 */
export function clearWarnings(guildId, userId) {
  const allWarnings = readJSON(WARNINGS_FILE, {});
  const guildKey = String(guildId);
  const userKey = String(userId);

  if (allWarnings[guildKey]?.[userKey]) {
    const count = allWarnings[guildKey][userKey].length;
    delete allWarnings[guildKey][userKey];
    writeJSON(WARNINGS_FILE, allWarnings);
    return count;
  }
  return 0;
}

// ==========================================
// 4. SOHBET VE KANAL YÖNETİMİ
// ==========================================

/**
 * Kanaldaki son X mesajı topluca siler.
 * @param {object} client - Jubbio client
 * @param {string} guildId - Sunucu ID
 * @param {string} channelId - Kanal ID
 * @param {number} amount - Silinecek mesaj sayısı (1-100)
 */
export async function purgeMessages(client, guildId, channelId, amount = 10, moderator = null) {
  const cleanAmount = Math.min(Math.max(parseInt(amount, 10) || 10, 1), 100);

  try {
    const messagesRes = await client.rest.getMessages(guildId, channelId, { limit: cleanAmount });
    const list = Array.isArray(messagesRes)
      ? messagesRes
      : messagesRes?.messages || messagesRes?.data || [];

    if (!list.length) return 0;

    const messageIds = list.map((m) => m.id).filter(Boolean);

    // Jubbio bulk delete dene
    try {
      await client.rest.bulkDeleteMessages(guildId, channelId, messageIds);
    } catch (_) {
      // Bulk delete başarısız olursa tek tek sil (güvenli fallback)
      for (const msgId of messageIds) {
        await sleep(300);
        try {
          await client.rest.deleteMessage(guildId, channelId, msgId);
        } catch (_) {}
      }
    }

    await logModerationAction(client, guildId, {
      action: 'Mesaj Temizliği (Purge)',
      moderator,
      target: channelId,
      reason: `${cleanAmount} adet mesaj silindi`,
    });

    return messageIds.length;
  } catch (err) {
    console.error('Mesaj silme hatası:', err.message);
    throw err;
  }
}

/**
 * Kanalı kilitler (üyelerin mesaj yazmasını kapatır).
 */
export async function lockChannel(client, guildId, channelId, reason = 'Kanal kilitlendi', moderator = null) {
  // @everyone rol ID'si genellikle guildId'dir
  await client.rest.editChannelPermissions(channelId, guildId, {
    type: 'role',
    allow: '0',
    deny: '2048', // SendMessages (2048) kapatıldı
  });

  await logModerationAction(client, guildId, {
    action: 'Kanal Kilitlendi',
    moderator,
    target: channelId,
    reason,
  });

  return true;
}

/**
 * Kanal kilidini açar (üyelerin mesaj yazmasını tekrar açar).
 */
export async function unlockChannel(client, guildId, channelId, moderator = null) {
  await client.rest.editChannelPermissions(channelId, guildId, {
    type: 'role',
    allow: '2048', // SendMessages izin verildi
    deny: '0',
  });

  await logModerationAction(client, guildId, {
    action: 'Kanal Kilidi Açıldı',
    moderator,
    target: channelId,
  });

  return true;
}

// ==========================================
// 5. DOĞAL DİL MODERASYON AYRIŞTIRICISI
// ==========================================

/**
 * Kullanıcının serbest metninden (örn: "@Qubix Ahmet'i 10dk sustur küfür etti")
 * moderasyon niyetini ve parametrelerini çıkarır.
 */
export function parseNaturalModeration(prompt) {
  if (!prompt || typeof prompt !== 'string') return null;
  const p = prompt.trim().toLowerCase();

  const userMentionMatch = prompt.match(/<@!?(\d+)>/);
  const channelMentionMatch = prompt.match(/<#!?(\d+)>/);
  const targetUserId = userMentionMatch ? userMentionMatch[1] : null;
  const targetChannelId = channelMentionMatch ? channelMentionMatch[1] : null;

  // 1. Susturma (Timeout / Mute)
  if (/(sustur|timeout|mute|sessize al)/i.test(p) && !/(kaldır|ac|aç|unmute|untimeout)/i.test(p)) {
    const duration = parseDuration(p) || 10 * 60 * 1000; // Varsayılan 10 dakika
    const reasonMatch = prompt.match(/(?:sebep|neden|çünkü|sebebiyle)\s*[:：\-]?\s*(.+)$/i);
    const reason = reasonMatch ? reasonMatch[1].trim() : 'Doğal dil komutu ile susturuldu';

    return {
      type: 'timeout',
      targetUserId,
      durationMs: duration,
      reason,
    };
  }

  // 2. Susturma Kaldırma
  if (/(sustur.*(?:kaldır|ac|aç)|untimeout|unmute)/i.test(p)) {
    return {
      type: 'untimeout',
      targetUserId,
    };
  }

  // 3. Sunucudan Atma (Kick)
  if (/(sunucudan at|kickle|kick|dışarı at)/i.test(p) && !/(yasakla|ban)/i.test(p)) {
    const reasonMatch = prompt.match(/(?:sebep|neden|çünkü)\s*[:：\-]?\s*(.+)$/i);
    const reason = reasonMatch ? reasonMatch[1].trim() : 'Yetkili tarafından sunucudan atıldı';
    return {
      type: 'kick',
      targetUserId,
      reason,
    };
  }

  // 4. Yasaklama (Ban)
  if (/(yasakla|banla|ban|sunucudan engelle)/i.test(p) && !/(kaldır|ac|aç|unban)/i.test(p)) {
    const reasonMatch = prompt.match(/(?:sebep|neden|çünkü)\s*[:：\-]?\s*(.+)$/i);
    const reason = reasonMatch ? reasonMatch[1].trim() : 'Yetkili tarafından yasaklandı';
    return {
      type: 'ban',
      targetUserId,
      reason,
    };
  }

  // 5. Yasak Kaldırma (Unban)
  if (/(yasak.*(?:kaldır|ac|aç)|unban)/i.test(p)) {
    const idMatch = prompt.match(/\b\d{16,21}\b/);
    return {
      type: 'unban',
      targetUserId: targetUserId || (idMatch ? idMatch[0] : null),
    };
  }

  // 6. Mesaj Silme (Purge)
  if (/(mesaj.*sil|mesajları temizle|sohbeti temizle|sil.*mesaj|temizle)/i.test(p) && !/(rol|kanal sil|kategori sil)/i.test(p)) {
    const amountMatch = prompt.match(/(\d+)\s*(?:adet|tane)?\s*mesaj/i) || prompt.match(/(?:sil|temizle)\s+(\d+)/i);
    const amount = amountMatch ? parseInt(amountMatch[1], 10) : 10;
    return {
      type: 'purge',
      amount,
      targetChannelId,
    };
  }

  // 7. Kanal Kilitleme (Lock)
  if (/(kanalı kilitle|sohbeti kilitle|kilit vur|yazmayı kapat|lock)/i.test(p) && !/(aç|ac|unlock)/i.test(p)) {
    return {
      type: 'lock',
      targetChannelId,
    };
  }

  // 8. Kanal Kilidi Açma (Unlock)
  if (/(kanal.*kilidini aç|sohbeti aç|yazmayı aç|kilidi kaldır|unlock)/i.test(p)) {
    return {
      type: 'unlock',
      targetChannelId,
    };
  }

  // 9. Uyarı (Warn)
  if (/(uyar\b|uyarı ver|ihtar ver|warn)/i.test(p) && !/(sil|temizle|bak|gör|liste)/i.test(p)) {
    const reasonMatch = prompt.match(/(?:sebep|neden|çünkü)\s*[:：\-]?\s*(.+)$/i);
    const reason = reasonMatch ? reasonMatch[1].trim() : 'Kural ihlali';
    return {
      type: 'warn',
      targetUserId,
      reason,
    };
  }

  return null;
}
