import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const outputDirectory = path.join(root, 'release', `qubix-bot-${packageJson.version}`);
const releaseFiles = [
  '.env.example',
  '.gitignore',
  'LICENSE',
  'README.md',
  'ai-router.js',
  'ai.js',
  'architect.js',
  'automod.js',
  'conversation-memory.js',
  'gemini-pool.js',
  'index.js',
  'moderation.js',
  'package-lock.json',
  'package.json',
  'prepare-release.js',
  'provider-check.js',
];

if (fs.existsSync(outputDirectory)) {
  throw new Error(
    `Yayın klasörü zaten mevcut: ${path.relative(root, outputDirectory)}. ` +
    'İçeriğini kontrol edip kaldırdıktan sonra komutu yeniden çalıştırın.',
  );
}

for (const file of releaseFiles) {
  const source = path.join(root, file);
  if (!fs.statSync(source).isFile()) {
    throw new Error(`Yayın için gerekli dosya bulunamadı: ${file}`);
  }
}

fs.mkdirSync(outputDirectory, { recursive: true });

for (const file of releaseFiles) {
  fs.copyFileSync(path.join(root, file), path.join(outputDirectory, file));
}

console.log(`Güvenli yayın klasörü hazır: ${path.relative(root, outputDirectory)}`);
console.log(`${releaseFiles.length} izinli dosya kopyalandı; yerel ayarlar ve çalışma verileri dahil edilmedi.`);
