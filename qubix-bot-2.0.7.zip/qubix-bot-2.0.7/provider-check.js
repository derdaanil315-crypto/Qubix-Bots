import 'dotenv/config';
import { GoogleGenAI } from '@google/genai';

const prompt = 'Yanıt olarak yalnızca OK yaz.';

function values(prefix) {
  const result = [];
  for (let index = 1; index <= 50; index++) {
    const value = process.env[`${prefix}_${index}`]?.trim();
    if (value) result.push(value);
  }
  if (result.length === 0 && process.env[prefix]?.trim()) result.push(process.env[prefix].trim());
  return [...new Set(result)];
}

function models(name, fallback) {
  const value = process.env[name]?.split(',').map(item => item.trim()).filter(Boolean);
  return value?.length ? [...new Set([...fallback, ...value])].slice(0, 3) : fallback;
}

async function checkGemini() {
  const keys = values('GEMINI_API_KEY');
  const modelList = models('GEMINI_MODELS', ['gemini-3.8-flash', 'gemini-2.5-flash']);
  for (let keyIndex = 0; keyIndex < keys.length; keyIndex++) {
    const client = new GoogleGenAI({ apiKey: keys[keyIndex] });
    for (const model of modelList) {
      try {
        const response = await client.models.generateContent({ model, contents: prompt });
        console.log(`GEMINI key ${keyIndex + 1}, ${model}: OK (${response.text?.trim() || 'empty'})`);
      } catch (error) {
        console.log(`GEMINI key ${keyIndex + 1}, ${model}: FAILED (${error.status || 'unknown'} ${error.message || error})`);
      }
    }
  }
}

async function checkCompatible(name, url, keys, modelList) {
  if (keys.length === 0) {
    console.log(`${name}: CONFIGURED KEY YOK`);
    return;
  }

  for (let keyIndex = 0; keyIndex < keys.length; keyIndex++) {
    for (const model of modelList) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            authorization: `Bearer ${keys[keyIndex]}`,
            'content-type': 'application/json',
            ...(name === 'OPENROUTER' ? {
              'HTTP-Referer': process.env.OPENROUTER_SITE_URL || 'https://jubbio.com',
              'X-Title': process.env.OPENROUTER_APP_NAME || 'Qubix',
            } : {}),
          },
          body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], max_tokens: 8 }),
          signal: controller.signal,
        });
        clearTimeout(timeout);
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(`${response.status} ${body?.error?.message || ''}`.trim());
        console.log(`${name} key ${keyIndex + 1}, ${model}: OK`);
      } catch (error) {
        if (error.name === 'AbortError') {
          console.log(`${name} key ${keyIndex + 1}, ${model}: FAILED (timeout)`);
          continue;
        }
        console.log(`${name} key ${keyIndex + 1}, ${model}: FAILED (${error.message || error})`);
      }
    }
  }
}

await checkGemini();
await checkCompatible('GROQ', 'https://api.groq.com/openai/v1/chat/completions', values('GROQ_API_KEY'), models('GROQ_MODELS', ['qwen/qwen3.8-27b']));
await checkCompatible('OPENROUTER', 'https://openrouter.ai/api/v1/chat/completions', values('OPENROUTER_API_KEY'), models('OPENROUTER_MODELS', ['qwen/qwen3.8-27b:free']));

